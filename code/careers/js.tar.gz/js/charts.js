/* 
 This file initialise the Google Visualization API and perform the AJAX calls
 to retrieve the data for all the charts.
 */

function load() {
	google.load("visualization", "1", {packages:["corechart"]});
}

function fetchData(vizURL) {
    return $.ajax({
        type: "GET",
        url: "/code/careers/proxy.php?v=" + vizURL,
        dataType:"json",
        async: false
        }).responseText;
}

function drawJobsByCountry() {
}

function drawJobsRemoteVsLocal() {
        var data = new google.visualization.DataTable(fetchData('remotevslocal'));
        var visualization = new google.visualization.PieChart(document.getElementById('remote_vs_local_chart'));
        visualization.draw(data, {is3D:true});
}

function drawJobsByTagCumulus() {
        var data = new google.visualization.DataTable(fetchData('tagcumulus'));
        var visualization = new gviz_word_cumulus.WordCumulus(document.getElementById('tag_chart_cumulus'));
        visualization.draw(data, {text_color: '#000000', speed: 30, width:400, height:400});
}

function drawJobsByTagCloud() { 
        var data = new google.visualization.DataTable(fetchData('tagcloud'));
	var visualization = new TermCloud(document.getElementById("tag_chart_cloud"));
        visualization.draw(data, null);
}

function handleError(response) {
        alert('Error in query: ' + response.getMessage() + ' ' + response.getDetailedMessage());
}

