#!/usr/bin/env python

""" 
This is Synkie, it is released under the Apache 2.0 License.
The license text is available online, I'm too lazy to copy it here.

Author: Marco Dinacci - www.intransitione.com -

TODO add an option to simulate the sync without actually doing it
TODO add visual progress when syncing
"""

import gtk,os,shutil
from time import sleep
from subprocess import Popen

from utils import *

# DO NOT forget to update these values if they're changed in Glade
TOGGLE_COLUMN = 0
FILENAME_COLUMN = 1
SOURCE_PATH_COLUMN = 0
DESTINATION_PATH_COLUMN = 0
SOURCE_LABEL_COLUMN = 2
INCONSISTENT_COLUMN = 3

FILESYSTEM_VIEW = "fs_vbox"
DIFF_VIEW = "diff_vbox"
NEW_FILES_VIEW = "new_files_view"
SOURCES_VIEW = "sources_view"
DESTINATION_VIEW = "destination_view"

SELECTION_STRING = '*'
INCONSISTENT_STRING = '-'
SAVE_FOLDER = "/home/marco/.config/synkie"

DESTINATIONS_DB = "/home/marco/.config/synkie/destinations.db"
SOURCES_DB = "/home/marco/.config/synkie/sources.db"

class StatusBar(object):
    def __init__(self, gtk_status_bar, progress_bar):
        self._sb = gtk_status_bar
        self._pb = progress_bar

    def __sleep(self,milliseconds):
        gobject.idle_add(sleep,milliseconds / 1000.0)

    def push(self,text,ctx_id=0,milliseconds=1500,clear=False):#True):
        self._sb.pop(ctx_id)
        self._sb.push(ctx_id,text)
        if clear:
            self.clear(milliseconds)

    def step(self,fraction):
        self._pb.set_fraction(fraction)

    def pulse(self):
        self._pb.pulse()

    def clear(self,milliseconds=1500):
        self.__sleep(milliseconds)
        self.push("",0,milliseconds,False)
        self._pb.set_fraction(0.0)

class DatabaseEntry(object):
    def __init__(self, path, label, icon):
        self.path = path
        self.label = label
        self.icon = icon

class PlainDatabase(object):
    """ 
    A database stored as a text file, where entries are sepatated with a ; 
    (basically a CSV file...)
    """
    def __init__(self, path):
        self._path = path
        self._entries = []

        if os.path.exists(self._path):
            db = open(self._path)
            for dbentry in db:
                entry,label,icon = dbentry.split(';')
                self._entries.append(DatabaseEntry(entry,label,icon[:-1]))
            db.close()

    def __iter__(self):
        return self._entries.__iter__()

    def __len__(self):
        return len(self._entries)


class ViewManager(object):
    """ Manage the available views (filesystem, diff, etc...) """
    def __init__(self, view):
        self.current_view = view
        self.previous_view = None
        self._views = [view]

    def add_view(self, view):
        if view not in self._views:
            self._views.append(view)

    def remove_view(self, view):
        if view in self._views:
            self._views.remove(view)

    def change_view(self, name):
        if self.current_view.get_name() == name:
            print "Not changing view"
            return

        for view in self._views:
            if name == view.get_name():
                self.current_view.set_property("visible",False)
                self.current_view.set_property("sensitive",False)
                parent = self.current_view.get_parent()
                parent.remove(self.current_view)
                #self.current_view.reparent(self._temp_parent)

                self.previous_view = self.current_view
                self.current_view = view
                parent.add(self.current_view)
                self.current_view.set_property("visible",True)
                self.current_view.set_property("sensitive",True)
                self.current_view.show_all()
                break

    def restore_previous_view(self):
        tmp = self.previous_view
        self.current_view.set_property("visible",False)
        self.previous_view = self.current_view
        self.current_view = tmp
        self.current_view.set_property("visible",True)


# global objects, TODO improve builder initialization
builder = gtk.Builder()
builder.add_from_file("/home/marco/dev/music/synkie.glade")
view_manager = ViewManager(builder.get_object(FILESYSTEM_VIEW))
view_manager.add_view(builder.get_object(DIFF_VIEW))
statusbar = StatusBar(builder.get_object("statusbar"), builder.get_object("progressbar"))

gtk.gdk.threads_init()

# private utilities 

def _get_selected_items():
    """ Get selected files """ 
    selected_items = []
    fsstore = builder.get_object("fs_store")
    fsstore.foreach(_mark_selected_items, selected_items)
    good_items = []
    # include only selected files (have a *)
    for item in selected_items:
        if item.startswith(SELECTION_STRING):
            good_items.append(item[1:])

    return good_items
                
def _get_value_from_selection(view_name, column):
    """ Return the value from the selected row at the given column in the given model """
    name = None
    view = builder.get_object(view_name)
    if view is None:
        print "Object %s does't exists, check calling function " % view_name
    store, iter = view.get_selection().get_selected()
    if iter is not None:
        name = store.get_value(iter,column)
    return name

def _populate_tree(tree, iter, path, saved_entries):
    """ Populate the given tree store with entries, normally called by foreach """
    # insert root in the tree
    inc = False
    
    # need to remove "-" from saved_entries entries
    selected = False
    for entry in saved_entries:
        if entry.startswith(INCONSISTENT_STRING):
            entry = entry[1:]
            inc = True
        else:
            inc = False
        if entry == path: 
            selected = True
            break
            
    if selected:
        if inc:
            saved_entries.remove("%s%s" % (INCONSISTENT_STRING,path))
        else:
            saved_entries.remove(path)
    iter = tree.append(iter, (selected,path,path,inc))
    
    # now insert children 
    for item in os.listdir(path):
        fullpath = os.path.join(path,item)
        if os.path.isdir(fullpath):
            _populate_tree(tree,iter,fullpath, saved_entries)
        else:
            selected = fullpath in saved_entries
            if selected:
                saved_entries.remove(fullpath)
            tree.append(iter, (selected, os.path.basename(fullpath), fullpath,0))
    

def _populate_store_from_db(store,db_path):
    """ Populate a model from a given database """
    db = PlainDatabase(db_path)
    pos = 0
    for db_entry in db:
        store.insert(pos, (db_entry.path,db_entry.icon, db_entry.label))
        pos = pos + 1

def _mark_selected_items(model,path,iter,selected_items=[]):
    """ Given a model, put in selected_items the marked entries """
    selected = SELECTION_STRING
    if model.iter_has_child(iter):
        if not model.get_value(iter, TOGGLE_COLUMN):
            selected = ''
        # write it but label it as a directory to avoid duplicate syncing
        # since the children are selected too
        filename = model.get_value(iter,FILENAME_COLUMN)
        inc = model.get_value(iter,INCONSISTENT_COLUMN)
        if inc is True:
            inc = INCONSISTENT_STRING
            selected = SELECTION_STRING
        else:
            inc = ""
        selected_items.append("%sD%s%s" % (selected,inc,filename))
    else:
        parent_iter = model.iter_parent(iter)
        parent_value = model.get_value(parent_iter,FILENAME_COLUMN)
        if not model.get_value(iter, TOGGLE_COLUMN):
            selected = ''
        selected_items.append("%s%s" % (selected,os.path.join(parent_value,model.get_value(iter,FILENAME_COLUMN))))

def _get_files_sets():
    """ Return a set containing the file found in a directory and another set
    with the files found in the save file. Useful as a start to make comparisons between
    directories """
    source_files = []
    
    def _populate_source_files(root):
        source_files.append(root)
        for source_file in os.listdir(root):
            fullpath = os.path.join(root,source_file)
            if os.path.isdir(fullpath):
                _populate_source_files(fullpath)
            source_files.append(fullpath)

    def _sanitize(line):
        if line.startswith(SELECTION_STRING):
            line = line[1:]
        if line.startswith('D'):
            line = line[1:]
            if line.startswith(INCONSISTENT_STRING):
                line = line[1:]

        return line[:-1]

    # load save file and scan directory 
    # return both as set

    sources_view = builder.get_object(SOURCES_VIEW)
    selection = sources_view.get_selection()
    sources_store, iter = selection.get_selected()
    # FIXME get rid of magic numbers
    source_name = sources_store.get_value(iter,2)
    source_path = sources_store.get_value(iter,0)
    save_file_path = os.path.join(SAVE_FOLDER, "%s.save" % source_name)
    
    if os.path.exists(save_file_path):
        save_file = open(save_file_path)
        save_file_lines = map(_sanitize, save_file.readlines())

    _populate_source_files(source_path)

    return set(source_files), set(save_file_lines)


def filesystem_visible_func(model, iter, user_data=None):
    text = builder.get_object("search_entry").get_text()
    result = False
    if text != "Search..." and len(text) > 0:
        value = model.get_value(iter, 2)#FILENAME_COLUMN)
        result = text in value
        print value
    return result


""" Callbacks """

def on_search_entry_changed(widget):
    builder.get_object("treemodelfilter").refilter()
    #builder.get_object("fs_view").show_all()

def on_include_toggle_toggled(widget, iter_path):
    
    """ Called when an item in the filesystem view is (un)selected """

    # Change the value of all the children of a node, recursively
    def _toggle_children_recursive(iter,value):
        for i in xrange(fstore.iter_n_children(iter)):
            child_iter = fstore.iter_nth_child(iter,i)
            fstore.set_value(child_iter,TOGGLE_COLUMN, value)
            if fstore.iter_has_child(child_iter):
                _toggle_children_recursive(child_iter, value)

    def _toggle_parent_state_recursive(model, iter):
        """ This does all the magic, (un)togglind and setting the inconsistent 
        value whether is necessary for every node """

        all_selected = True
        all_unselected = True
        for i in xrange(0,model.iter_n_children(iter)):
            child = fstore.iter_nth_child(iter, i)
            toggled = fstore.get_value(child,TOGGLE_COLUMN)
            all_selected = all_selected and toggled
            all_unselected = all_unselected and not toggled
        if all_selected:
            fstore.set_value(iter,TOGGLE_COLUMN,True)
            fstore.set_value(iter,INCONSISTENT_COLUMN,False)
        else: 
            fstore.set_value(iter,TOGGLE_COLUMN,False)
            fstore.set_value(iter,INCONSISTENT_COLUMN,True)

        # Now that the values are set, check whether ALL children are 
        # unselected, if they are, set INCONSISTENT as False
        # if all_unselected: should be an optimization...
        inc = True
        for i in xrange(0,model.iter_n_children(iter)):
            child = fstore.iter_nth_child(iter, i)
            inc = fstore.get_value(child,INCONSISTENT_COLUMN)
            all_unselected = all_unselected and not inc
        if all_unselected:
            fstore.set_value(iter, INCONSISTENT_COLUMN, False)
        
        # recurse
        parent_iter = model.iter_parent(iter)
        if parent_iter is not None:
            _toggle_parent_state_recursive(model,parent_iter)


    fstore = builder.get_object("fs_store")
    
    # Invert the selected value 
    iter = fstore.get_iter_from_string(iter_path)
    value = not fstore.get_value(iter,TOGGLE_COLUMN)
    fstore.set_value(iter,TOGGLE_COLUMN,value)

    # if the node has children, also change their toggle state
    if fstore.iter_has_child(iter):
        _toggle_children_recursive(iter,value)
        _toggle_parent_state_recursive(fstore,iter)
    else:
        parent_iter = fstore.iter_parent(iter)
        _toggle_parent_state_recursive(fstore, parent_iter)

def on_add_source_cancel_button_clicked(widget):
    builder.get_object("add_source_dialog").hide()

def on_sources_changed(treeview):
    # change view if necessary
    view_manager.change_view(FILESYSTEM_VIEW)

    # activate toolbar if not activated
    builder.get_object("toolbar").set_property("sensitive",True)

    selection = treeview.get_selection()
    sources_store, iter = selection.get_selected()
    path = sources_store.get_value(iter,SOURCE_PATH_COLUMN)

    if os.path.exists(path):
        fsstore = builder.get_object("fs_store")
        fsstore.clear()

        # load save file if exists
        save_file = os.path.join(SAVE_FOLDER, "%s.save" % sources_store.get_value(iter,SOURCE_LABEL_COLUMN))
        saved_entries = []

        if os.path.exists(save_file):
            statusbar.push("Reading save file at: %s" % save_file)
            f = open(save_file)

            def loop():
                lines = f.readlines()
                max = len(lines)
                i = 0
                for entry in lines:
                    entry = entry[:-1]
                    entry_was_saved = False

                    if entry.startswith(SELECTION_STRING):
                        entry_was_saved = True
                        entry = entry[1:]
                        if entry.startswith('D'):
                            entry = entry[1:]
                        saved_entries.append(entry)

                    fraction = i / float(max)
                    i = i+1
                    #sleep(0.0001)
                    yield fraction

            def populate_tree():
                _populate_tree(fsstore, None, path, saved_entries)
                statusbar.push("Done.")
            
            # read the file in another thread in order to update the status bar
            Task(loop,statusbar.step,populate_tree).start()

    # activate the toolbar
    builder.get_object("fs_toolbar").set_property("sensitive",True)


def on_fs_view_cursor_changed(treeview):
    model, iter = treeview.get_selection().get_selected()
    if iter is not None:
        view_action = builder.get_object("view_action")

        if model.iter_has_child(iter):
            view_action.set_property("sensitive", False)
        else:
            view_action.set_property("sensitive", True)


def on_show_source_dialog_action_activate(action):
    builder.get_object("add_source_dialog").show()

def on_view_action_activate(action):
    model, iter = builder.get_object("fs_view").get_selection().get_selected()
    value = model.get_value(iter, 2)
    cmd = "gnome-open %s" % value
    Popen(cmd.split(" ", 1))

def on_read_save_file_action_activate(action, user_data):
    statusbar.push("Reading save file...")

    statusbar.clear()
    user_data = ["b"]

# TODO unify this and following function
def on_new_files_action_activate(action):
    widget = builder.get_object("new_files_button")
    is_active = widget.get_active()
    intersection = set()

    if is_active:
        fs_set, saved_set = _get_files_sets()

        sym_diff = fs_set.symmetric_difference(saved_set)
        intersection =  fs_set.intersection(sym_diff)

        view_manager.change_view(NEW_FILES_VIEW)
    else:
        view_manager.restore_previous_view()

    return intersection

def on_deleted_files_action_activate(action):
    widget = builder.get_object("deleted_files_button")

    is_active = widget.get_active()
    intersection = set()
    if is_active:
        fs_set, saved_set = _get_files_sets()

        sym_diff = fs_set.symmetric_difference(saved_set)
        intersection = saved_set.intersection(sym_diff)

        return intersection

def on_expand_all_action_activate(widget):
    view = builder.get_object("fs_view")
    selection = view.get_selection()
    if selection is not None:
        model,iter = selection.get_selected()
        view.expand_row(model.get_path(iter), True)

def on_sync_action_activate(widget):
    # get the source directory so we know which directory to recreate
    source_path = _get_value_from_selection(SOURCES_VIEW, SOURCE_PATH_COLUMN)

    # get the destination path, if it doesn't exists try to create it
    # TODO replace with _get_value_from_selection
    dest_view = builder.get_object(DESTINATION_VIEW)
    selection = dest_view.get_selection()
    dest_store, iterator = selection.get_selected()
    if iterator is not None:
        root_path = dest_store.get_value(iterator, DESTINATION_PATH_COLUMN)
        dest_path = os.path.join(root_path,os.path.basename(source_path))
        if not os.path.exists(dest_path):
            # try to create it
            try:
                os.mkdir(dest_path)
            except Exception, e:
                # TODO report error to interface
                return
        
        # first remove the deleted files from destination
        deleted_files_store = builder.get_object("deleted_files_store")
        iterator = deleted_files_store.get_iter_root()
        dirs = []
        while iterator is not None:
            # get rid of the first slash or os.path.join won't work
            del_file = deleted_files_store.get_value(iterator,0)[1:]
            del_file = os.path.join(dest_path,del_file)
            if os.path.isdir(del_file):
                dirs.append(del_file)
            else:
                os.remove(del_file)
                print "Removed file: ", del_file
            iterator = deleted_files_store.iter_next(iterator)

        # sort dirs by length so subdir are eliminated first
        dirs.sort(cmp=sort_by_length)
        for folder in dirs:
            if os.path.exists(folder):
                os.rmdir(folder)
                print "Removed folder: ", folder
            else:
                print "Folder %s does not exists ?!" % folder

        dirs = []
        # now add the new files
        selected_items = []
        store = builder.get_object("new_files_store")
        iterator = store.get_iter_root()
        while iterator is not None:
            folder = dest_path
            item = store.get_value(iterator,0)[1:]
            item = os.path.join(source_path,item)

            head = os.path.dirname(item)

            print "Item is: ", item

            # ex: source = /home/marco item = /home/marco/foo/bar
            # dirs = ["foo","bar"]
            dirs = item.partition(source_path)[-1].split("/")
            dirs = filter(lambda x: x != '',dirs)
            if not os.path.isdir(item):
                dirs = dirs[:-1] # last entry is the file name
            for x in range(0,len(dirs)):
                folder = os.path.join(folder,dirs[x])
                if not os.path.exists(folder):
                    os.mkdir(folder)
                    print "Created directory ", folder
            dest_file = os.path.join(folder,os.path.basename(item))
            if not os.path.isdir(item) and not os.path.exists(dest_file):
                shutil.copy(item, folder)
                print "Copied %s to %s" % (item, folder) 
            else:
                # FIXME why it happens so often?
                if os.path.exists(dest_file):
                    print "File %s already exists, not copying" % dest_file
            iterator = store.iter_next(iterator)
    else:
        print "Iter is none, no destination selected"

    deleted_files_store.clear()
    store.clear()
    print "Synking complete !"

def on_sort_action_activate(widget):
    pass

def on_save_action_activate(widget):
    """ Save the selected source on disk """
    selected_items = []
    
    fsstore = builder.get_object("fs_store")
    fsstore.foreach(_mark_selected_items, selected_items)

    sources_view = builder.get_object(SOURCES_VIEW)
    selection = sources_view.get_selection()
    sources_store, iter = selection.get_selected()

    if iter is not None:
        source_name = sources_store.get_value(iter,SOURCE_LABEL_COLUMN)

        path = os.path.join(SAVE_FOLDER, "%s.save" % source_name)
        f = open(path, 'w')
        for selected_item in selected_items:
            f.write("%s\n" % selected_item)

        f.close()
    print "Save completed"


def on_diff_action_activate(widget):
    source_path = _get_value_from_selection(SOURCES_VIEW, SOURCE_PATH_COLUMN)
    dest_path = _get_value_from_selection(DESTINATION_VIEW, DESTINATION_PATH_COLUMN)
    if None in (source_path,dest_path):
        print "TODO show error dialog, user didn't select source or destination"
        return

    dest_path = os.path.join(dest_path,os.path.basename(source_path))

    files_at_dest = walk_directory(dest_path)
    files_at_source = _get_selected_items()

    # strip the path from beginning to source name
    # ex. /media/disk/Music/a/b/c.mp3 must become /a/b/c.mp3
    files_at_source = set(map(lambda x: x.partition(source_path)[-1], files_at_source))
    files_at_dest = set(map(lambda x: x.partition(dest_path)[-1], files_at_dest))
    
    new_files = files_at_source - files_at_dest
    deleted_files = files_at_dest - files_at_source
    unchanged_files = files_at_source.intersection(files_at_dest) - new_files - deleted_files

    # populate diff models TODO, change to a tree model instead of using a list
    new_files_store = builder.get_object("new_files_store")
    deleted_files_store = builder.get_object("deleted_files_store")
    unchanged_files_store = builder.get_object("unchanged_files_store")
    new_files_store.clear()
    deleted_files_store.clear()
    unchanged_files_store.clear()

    pos = 0
    for new_file in new_files:
        if len(new_file) > 0:
            # if it's not just an empty string 
            new_files_store.insert(pos, (os.path.join(source_path,new_file), new_file))
        pos = pos+1
    pos = 0
    for deleted_file in deleted_files:
        if len(deleted_file) > 0:
            deleted_files_store.insert(pos,(os.path.join(source_path,deleted_file),deleted_file))
        pos = pos+1
    pos = 0
    for unchanged_file in unchanged_files:
        if len(unchanged_file) > 0:
            unchanged_files_store.insert(pos,(os.path.join(source_path,unchanged_file),unchanged_file))
        pos = pos+1
    
    view_manager.change_view(DIFF_VIEW)

    print "Diff completed"


def _fs_compare_function(model, iter1, iter2, user_data=None):
    value1 = model.get_value(iter1,1)
    value2 = model.get_value(iter2,1)

    if value1 > value2: return 1
    elif value2 > value1: return -1
    elif value1 == value2: return 0


if __name__ == "__main__":
    window = builder.get_object("main_window")

    # connections: shouldn't them be automatically handled if defined in glade ?
    window.connect("destroy", gtk.main_quit)
    # actions
    builder.get_object("expand_all_action").connect("activate", on_expand_all_action_activate)
    builder.get_object("sync_action").connect("activate", on_sync_action_activate)
    builder.get_object("save_action").connect("activate", on_save_action_activate)
    builder.get_object("sort_action").connect("activate", on_sort_action_activate)
    builder.get_object("diff_action").connect("activate", on_diff_action_activate)
    builder.get_object("view_action").connect("activate", on_view_action_activate)
    builder.get_object("new_files_action").connect("activate", on_new_files_action_activate)
    builder.get_object("deleted_files_action").connect("activate", on_deleted_files_action_activate)
    builder.get_object("show_source_dialog_action").connect("activate",on_show_source_dialog_action_activate)
    #builder.get_object("add_source_action").connect("activate",on_add_source_action_activate)
    builder.get_object("add_source_cancel_button").connect("clicked",on_add_source_cancel_button_clicked)
    
    # various
    builder.get_object("fs_view").connect("cursor_changed", on_fs_view_cursor_changed)
    builder.get_object("include_toggle").connect("toggled", on_include_toggle_toggled)
    builder.get_object(SOURCES_VIEW).connect("cursor-changed", on_sources_changed)
    builder.get_object("search_entry").connect("changed", on_search_entry_changed)
    builder.get_object("treemodelfilter").set_visible_func(filesystem_visible_func)

    # set the sort function for the filesystem model
    fs_store = builder.get_object("fs_store")
    fs_store.set_sort_column_id(1, gtk.SORT_ASCENDING)
    fs_store.set_sort_func(1,_fs_compare_function)

    # populate sources and destinations
    sources_store = builder.get_object("sources_store")
    _populate_store_from_db(sources_store,SOURCES_DB)
    dest_store = builder.get_object("destinations_store")
    _populate_store_from_db(dest_store, DESTINATIONS_DB)

    builder.get_object("sources_expander").set_expanded(True)
    builder.get_object("destinations_expander").set_expanded(True)

    window.show()
    gtk.gdk.threads_init()
    gtk.main()
