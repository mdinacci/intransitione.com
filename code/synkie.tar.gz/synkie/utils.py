import os, threading, thread
import gobject, gtk

all = ["walk_directory,sort_by_length,sort_by_length_inverse,Task"]

def walk_directory(path):
    """ Return all files from path, exploring all the subfolders """
    all_files = []
    if os.path.isdir(path):
        for root, sub_dirs, files in os.walk(path):
            for sub_dir in sub_dirs:
                all_files.append(os.path.join(root,sub_dir))
            for file in files:
                all_files.append(os.path.join(root,file))
    else:
        print "directory %s not found TODO, show an error dialog" % path
    return all_files
    
def sort_by_length(a,b):
    if len(a) > len(b): return -1
    elif len(b) > len(a): return 1
    else: return 0

def sort_by_length_inverse(a,b):
    if len(a) > len(b): return 1
    elif len(b) > len(a): return -1
    else: return 0


# from http://un-pythonic.appspot.com/
class Task(object):

    def __init__(self, generator, loop_callback, complete_callback=None):
        self.generator = generator
        self.loop_callback = loop_callback
        self.complete_callback = complete_callback

    def _start(self, *args, **kwargs):
        self._stopped = False
        for ret in self.generator(*args, **kwargs):
            if self._stopped:
                thread.exit()
            gobject.idle_add(self._loop, ret)
        if self.complete_callback is not None:
            gobject.idle_add(self.complete_callback)

    def _loop(self, ret):
        if ret is None:
            ret = ()
        if not isinstance(ret, tuple):
            ret = (ret,)
        self.loop_callback(*ret)

    def start(self, *args, **kwargs):
        threading.Thread(target=self._start, args=args, kwargs=kwargs).start()

    def stop(self):
        self._stopped = True
