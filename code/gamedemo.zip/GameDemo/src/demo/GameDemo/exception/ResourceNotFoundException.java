package demo.GameDemo.exception;

public class ResourceNotFoundException extends Exception {

}
