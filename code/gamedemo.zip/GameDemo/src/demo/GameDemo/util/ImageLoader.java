package demo.GameDemo.util;

import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsEnvironment;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.WeakHashMap;

import javax.imageio.ImageIO;

public class ImageLoader {

	private static class ImageCache {
		private WeakHashMap mappings = new WeakHashMap();
		
		public void cacheImageWithKey(BufferedImage i, Object key) {
			mappings.put(key, i);
		}
		
		public BufferedImage getImageWithKey(Object key) {
			return (BufferedImage) mappings.get(key);
		}
	}
	
	static ImageCache cache = new ImageCache();
	
	/**
	 * Load an image from filesystem and try to render it in hardware.
	 */
	public static BufferedImage loadImage(File f) {
		// try to load image from cache before
		BufferedImage cachedImage = cache.getImageWithKey(f);
		if(cachedImage != null) 
			return cachedImage;
		
		// if there's a cache miss there's no option that loading the image from filesystem.
		GraphicsEnvironment graphicEnv = GraphicsEnvironment.getLocalGraphicsEnvironment();
		GraphicsConfiguration graphicConf = graphicEnv.getDefaultScreenDevice().getDefaultConfiguration();
		
		BufferedImage image = null;
		
		try {
			image = ImageIO.read(f);
			int transparency = image.getColorModel().getTransparency();
			BufferedImage compatibleImage = graphicConf.createCompatibleImage(image.getWidth(), image.getHeight(), transparency);
			
			Graphics2D graphicContext = (Graphics2D) compatibleImage.getGraphics();
			graphicContext.drawImage(image, 0, 0, null);
			
			cache.cacheImageWithKey(image, f);
			return compatibleImage;
			
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}
}

