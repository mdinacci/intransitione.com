package demo.GameDemo.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class Configuration {

	private static Configuration instance;
	private static final String BASE_PATH = "resources";
	private Properties properties;
	
	private Configuration() {
		properties = new Properties();
	    try {
			properties.load(new FileInputStream(BASE_PATH + "/resources.properties"));
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	private String fullPath(String property) {
		return BASE_PATH + "/" + property;
	}
	
	public static Configuration getInstance() {
		if(null == instance) {
			instance = new Configuration();
		}
		
		return instance;
	}
	
	public String resourceFullPathForProperty(String property)  {
		return fullPath(resourceForProperty(property));
	}
	
	public String resourceForProperty(String property) {
		return properties.getProperty(property);
	}
}
