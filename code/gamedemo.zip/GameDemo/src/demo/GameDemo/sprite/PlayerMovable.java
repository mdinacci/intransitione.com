package demo.GameDemo.sprite;

public interface PlayerMovable {
	void moveWest();
	void moveEast();
	void moveNorth();
	void moveSouth();
}
