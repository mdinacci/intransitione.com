package demo.GameDemo.sprite;

import java.awt.Dimension;
import java.awt.Point;

public class Aircraft extends HorizontalScrollingSprite {
	
	public Aircraft(Point location, Dimension size) {
		super(location, size, "helicopter");
		speed = 3;
	}
	
	public void update() {
		if(isCollidingWithScreenBorders()) {
			invertDirection();
		}
		
		if(currentDirection == Direction.EAST)  
			location.x += speed;
		else
			location.x -= speed;
	}
	
	public void setLocation(Point p) {
		System.out.println("Setting location in Aircraft!");
		super.setLocation(p);
		
	}
}
