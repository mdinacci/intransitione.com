package demo.GameDemo.sprite;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.File;

import demo.GameDemo.util.Drawable;
import demo.GameDemo.util.ImageLoader;

public class Sprite implements Drawable {
	
	protected Dimension size;
	protected BufferedImage image;
	protected Point location;
	protected int speed = 5;

	protected static final class Direction {
		public static final Direction NORTH = new Direction("North");
		public static final Direction SOUTH = new Direction("South");
		public static final Direction EAST = new Direction("East");
		public static final Direction WEST = new Direction("West");
		
		private String name;
		
		private Direction(String name) {
			this.name = name;
		}
		
		public String toString() {
			return name;
		}
	}
	
	public Sprite(Point location, Dimension size) {
		this.location = location;
		this.size = size;
	}
	
	public Rectangle getBoundingBox() {
		return new Rectangle(location.x, location.y, size.width, size.height);
	}
	
	public void draw(Graphics g) {
		g.drawImage(image, location.x, location.y, null);
	}

	public void update() {
		// do nothing
	}
	
	public void setImage(BufferedImage image) {
		if(this.image != image)
			this.image = image;
	}
	
	public void setImage(File image) {
		this.image = ImageLoader.loadImage(image);
	}
	
	public int getSpeed() {
		return speed;
	}
	
	public void setSpeed(int speed) {
		this.speed = speed;
	}

	public Point getLocation() {
		return location;
	}

	public void setLocation(Point location) {
		this.location = location;
	}

	public Dimension getSize() {
		return size;
	}

	public void setSize(Dimension size) {
		this.size = size;
	}
	
	public Point getMiddlePoint() {
		return new Point(location.x + size.width/2, location.y + size.height/2);
	}
}
