package demo.GameDemo.sprite;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.io.File;
import java.util.HashMap;

import demo.GameDemo.gui.GamePanel;
import demo.GameDemo.util.Configuration;

public class HorizontalScrollingSprite extends Sprite {

	private static final String EAST_SUFFIX = "_east";
	private static final String WEST_SUFFIX = "_west";
	
	protected Direction currentDirection;
	protected Direction previousDirection;
	
	private HashMap imageFileForDirection;
	private File eastImageFile;
	private File westImageFile;
	
	public HorizontalScrollingSprite(Point location, Dimension size, String name) {
		super(location, size);
		currentDirection = previousDirection = Direction.EAST;
		
		Configuration config = Configuration.getInstance();
		
		eastImageFile = new File(config.resourceFullPathForProperty(name + EAST_SUFFIX));
		westImageFile = new File(config.resourceFullPathForProperty(name + WEST_SUFFIX));
		
		imageFileForDirection = new HashMap();
		imageFileForDirection.put(Direction.EAST, eastImageFile);
		imageFileForDirection.put(Direction.WEST, westImageFile);
		
		setImage(eastImageFile);
	}

	protected boolean isCollidingWithScreenBorders() {
		return location.x <= 0 || location.x >= (GamePanel.WIDTH - size.width);
	}
	
	protected void enterScreenFromOppositeSide() {
		if(currentDirection == Direction.EAST)
			location.x = 0 - size.width;
		else
			location.x = GamePanel.WIDTH;
	}

	protected boolean isOutOfScreen() {
		return location.x < 0 - size.width || location.x > GamePanel.WIDTH + size.width;
	}
	
	protected void invertDirection() {
		if(currentDirection == Direction.EAST) {
			setCurrentDirection(Direction.WEST);
		} else {
			setCurrentDirection(Direction.EAST);
		}
	}
	
	protected void setCurrentDirection(Direction direction) {
		if(direction == currentDirection) return;
		
		previousDirection = currentDirection;
		currentDirection = direction;
		
		setImage((File)imageFileForDirection.get(currentDirection));
	}
	
	public void draw(Graphics g) {
		g.drawImage(image, location.x, location.y, null);
	}	
	
}
