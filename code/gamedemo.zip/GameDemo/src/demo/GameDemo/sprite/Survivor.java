package demo.GameDemo.sprite;

import java.awt.Dimension;
import java.awt.Point;
import java.io.File;

import demo.GameDemo.gui.GamePanel;
import demo.GameDemo.util.Configuration;

public class Survivor extends Sprite {

	private static final Dimension DEFAULT_DIMENSION = new Dimension(18,23);
	
	public Survivor(Point location, Dimension size) {
		super(location, size);
		setImage(new File(Configuration.getInstance().resourceFullPathForProperty("survivor")));
	}
	
	public Survivor(Point location, int speed) {
		this(location, DEFAULT_DIMENSION);
		this.speed = speed;
	}

	public void update() {
		if(!isSunk())
			location.y += speed;
	}
	
	public boolean isSunk() {
		return location.y > GamePanel.HEIGHT;
	}
}
