package demo.GameDemo;

import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JFrame;

import demo.GameDemo.gui.GamePanel;

public class GameRunner extends JFrame implements WindowListener {

	public GameRunner() {
		GamePanel gamePanel = new GamePanel();
		getContentPane().add(gamePanel);
		addWindowListener(this);
		pack();
		setTitle("CatchDaMan");
		setResizable(false);
		setVisible(true);
	}
	
	public static void main(String[] args) {
		new GameRunner();
	}

	public void windowOpened(WindowEvent arg0) {
	}

	public void windowClosing(WindowEvent arg0) {
	}

	public void windowClosed(WindowEvent arg0) {
	}

	public void windowIconified(WindowEvent arg0) {
	}

	public void windowDeiconified(WindowEvent arg0) {
	}

	public void windowActivated(WindowEvent arg0) {
	}

	public void windowDeactivated(WindowEvent arg0) {
	}
}
