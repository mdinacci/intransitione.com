package demo.GameDemo.gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.Observable;
import java.util.Observer;

import javax.swing.JPanel;

import demo.GameDemo.sprite.Aircraft;
import demo.GameDemo.sprite.Hero;
import demo.GameDemo.sprite.HorizontalScrollingSprite;
import demo.GameDemo.sprite.Sprite;
import demo.GameDemo.sprite.Survivor;
import demo.GameDemo.sprite.SurvivorFactory;
import demo.GameDemo.util.Configuration;
import demo.GameDemo.util.ImageLoader;
import demo.GameDemo.util.Score;

public class GamePanel extends JPanel implements Runnable, Observer {
	
	static public final int WIDTH = Integer.parseInt(Configuration.getInstance().resourceForProperty("screen_width"));
	static public final int HEIGHT = Integer.parseInt(Configuration.getInstance().resourceForProperty("screen_height"));
	
	private boolean running;
	private boolean gameOver;
	private HorizontalScrollingSprite aircraft;
	private Hero hero;
	private Graphics doubleBufferGraphics;
	private Image doubleBufferImage;
	private Thread animator;
	private GameBackground background;
	private volatile Collection sprites;
	private Score score;
	private SurvivorFactory survivorFactory;
	
	private volatile boolean isLocked;
	
	private class GameBackground extends demo.GameDemo.sprite.Sprite  {

		public GameBackground(File file) {
			super(new Point(0,0), new Dimension(WIDTH, HEIGHT));
			setImage(ImageLoader.loadImage(file));
		}
	}
	
	public GamePanel() {
		setPreferredSize(new Dimension(WIDTH, HEIGHT));
		setFocusable(true);
		setBackground(new File(Configuration.getInstance().resourceFullPathForProperty("background")));
		setupInputListeners();
		requestFocus();
	}
	
	private void setupInputListeners() {
		addKeyListener(
				new KeyAdapter() {
					public void keyPressed(KeyEvent e) {
						handleKeyPress(e);
					}
				});
		
		addMouseListener(
				new MouseAdapter() {
					public void mousePressed(MouseEvent e) {
						handleMousePress(e);
					}
				});
	}
	
	private void swapBuffers() { 
		Graphics g;
		try {
			g = getGraphics();
			if ((g != null) && (doubleBufferImage  != null))
				g.drawImage(doubleBufferImage, 0, 0, null);
			Toolkit.getDefaultToolkit().sync();
			g.dispose();
		}
		catch (Exception e) {
			System.out.println("Can't swap buffers: " + e);  
		}
	}
	
	protected void handleMousePress(MouseEvent e) {
		// do nothing
	}
	
	protected void handleKeyPress(KeyEvent e) {
		if(isTerminationEvent(e)) {
			running = false; 
		}
		
		int keycode = e.getKeyCode();
		
		if(!gameOver) {
			if(keycode == KeyEvent.VK_LEFT) {
				hero.moveWest();
			} else if(keycode == KeyEvent.VK_RIGHT) {
				hero.moveEast();
			}
		} 
	}
	
	protected static boolean isTerminationEvent(KeyEvent keyEvent) {
		int keycode = keyEvent.getKeyCode();
		return (keycode == KeyEvent.VK_ESCAPE || keycode == KeyEvent.VK_Q ||
				keycode	== KeyEvent.VK_END || (keycode == KeyEvent.VK_C && keyEvent.isControlDown()));
	}
	
	protected void updateLogic() {
		if(gameOver) return;
		
		isLocked = true;
		
		Iterator iter = sprites.iterator();
		while (iter.hasNext()) {
			Sprite sprite = (Sprite) iter.next();
			sprite.update();
		}

		isLocked = false;
		
		updateScore();
		
	}

	private void updateScore() {
		
		isLocked = true; 
		
		Iterator iter = sprites.iterator();
		Collection survivorsToRemove = new ArrayList();
		while (iter.hasNext()) {
			Sprite sprite = (Sprite) iter.next();
			if (sprite instanceof Survivor) {
				Survivor survivor = (Survivor) sprite;
				if(survivor.getBoundingBox().intersects(hero.getBoundingBox())) {
					survivorsToRemove.add(survivor);
					score.incrementPoints(1);
				} else if(survivor.isSunk()) {
					survivorsToRemove.add(survivor);
					score.decrementLifes(1);
					if(score.getLifes() <= 0) {
						setGameOver(true);
					}
				}
			}
		}
		
		iter = survivorsToRemove.iterator();
		while (iter.hasNext()) {
			sprites.remove(iter.next());
		}
		
		isLocked = false;
	}
	
	protected void render() {
		setupDoubleBuffer();
		
		background.draw(doubleBufferGraphics);
		
		isLocked = true;
		
		Iterator iter = sprites.iterator();
		while (iter.hasNext()) {
			Sprite sprite = (Sprite) iter.next();
			sprite.draw(doubleBufferGraphics);
		}
		
		isLocked = false;
		
		score.draw(doubleBufferGraphics);
		
		if(gameOver) {
			doubleBufferGraphics.setFont(new Font("SansSerif", Font.BOLD, 24));
			doubleBufferGraphics.drawString("Game Over", WIDTH /2-50, HEIGHT/2);
		}
		
	}
	
	protected void setupDoubleBuffer() {
		if (doubleBufferImage == null){
			doubleBufferImage = createImage(WIDTH, HEIGHT);
			if (doubleBufferImage == null) {
				System.out.println("Double buffer image is null");
				return;
			}
			else
				doubleBufferGraphics = doubleBufferImage.getGraphics();
		}
		
		doubleBufferGraphics.setColor(Color.WHITE);
		doubleBufferGraphics.fillRect(0, 0, WIDTH, HEIGHT);
	}
	
	protected void createSprites() {
		
		sprites = null;
		sprites = Collections.synchronizedList(new ArrayList());
		
		// FIXME remove hard-coded (image) dimensions
		hero = new Hero(new Point(WIDTH/2, HEIGHT-78), new Dimension(133,78));
		aircraft = new Aircraft(new Point(WIDTH/2, 40), new Dimension(90,24));
		
		sprites.add(hero);
		sprites.add(aircraft);
		
		Point point = new Point(aircraft.getMiddlePoint());
		//sprites.add(new Survivor(point,2));
	}
	
	public void setBackground(File file) {
		background = new GameBackground(file);
	}
	
	public void startGame() {

		createSprites();
		score = new Score(5, 0);
		
		// rendering thread
		if(animator == null || !running) {
			animator = new Thread(this);
			animator.start();
		}
		
		if(survivorFactory == null || !running) {
			survivorFactory = SurvivorFactory.getInstance();
			survivorFactory.setTargetForSpawnLocation(aircraft);
			survivorFactory.addObserver(this); // si registra per ricevere notifiche di nuovi survivor creati
		}
	}
	
	public void setGameOver(boolean value) {
		gameOver = value;
	}
	
	public void addNotify() { 
		super.addNotify();
		startGame();
	}
	
	public void run() {
		running = true;
		
		while(running) {
			try {
				Thread.sleep(20);
			} catch(InterruptedException ex){}
			
			//synchronized(this) {
				updateLogic();
				render();
			//}
			swapBuffers();
		}
		
		System.out.println("Exiting...");
		System.exit(0);
	}

	public void update(Observable observable, Object message) {
		if(message instanceof Sprite) {
			while(isLocked) {
				try {
					Thread.sleep(10);
				} catch(InterruptedException ex) {}
			}
			
			synchronized (sprites) {
				sprites.add((Sprite)message);
			}
		}
	}
}
