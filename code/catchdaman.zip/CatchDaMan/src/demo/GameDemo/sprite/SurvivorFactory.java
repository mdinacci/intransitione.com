package demo.GameDemo.sprite;

import java.awt.Point;
import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import java.util.Random;

public class SurvivorFactory extends Observable implements Runnable {

	private static SurvivorFactory instance;
	private List cache;
	private final int CACHE_SIZE = 16;
	private int counter = 0;
	private int currentSpeed;
	private Sprite targetSprite;
	private Random randomGenerator;
	private static final int MIN_SPEED = 2;
	private static final int MAX_SPEED = 5;
	
	private SurvivorFactory() {
		randomGenerator = new Random((long) Math.random());
		
		cache = new ArrayList();
		new Thread(this).start();
	}
	
	public static SurvivorFactory getInstance() {
		if(instance == null) {
			instance = new SurvivorFactory();
		}
		
		return instance;
	}
	
	public synchronized void setTargetForSpawnLocation(Sprite targetSprite) {
		this.targetSprite = targetSprite;
	}
	
	private void createSurvivorAtLocationWithSpeed(Point location, int speed) {
		Survivor survivor = null;
		
		if(cache.size() < CACHE_SIZE) 
			survivor = new Survivor(location, speed);
		else {
			survivor = (Survivor) cache.get(0);
			survivor.setSpeed(speed);
			survivor.setLocation(location);
		}
		
		setChanged();
		notifyObservers(survivor);
	}
	
	public void cacheSurvivor(Survivor s) {
		if(cache.size() >= CACHE_SIZE)
			cache.remove(0);
		
		cache.add(s);
	}

	public void run() {
		while(true) {
			try {
				Thread.sleep(1000); 
			} catch(InterruptedException e) {};
			
			Point targetLocation =  (Point) targetSprite.getLocation().clone();
			
			currentSpeed = randomGenerator.nextInt(MAX_SPEED);
			if(currentSpeed < MIN_SPEED) currentSpeed = MIN_SPEED;
			
			createSurvivorAtLocationWithSpeed(targetLocation, currentSpeed);
			counter++;
		}
	}

}
