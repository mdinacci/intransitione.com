package demo.GameDemo.sprite;

import java.awt.Dimension;
import java.awt.Point;

public class Hero extends HorizontalScrollingSprite implements PlayerMovable {
	
	public Hero(Point location, Dimension size) {
		super(location, size, "hero");
		speed = 15;
	}

	public void update() {
		if(isOutOfScreen()) {
			enterScreenFromOppositeSide();
		}
	}

	public void moveWest() {
		setCurrentDirection(Direction.WEST);
		location.x -= speed;
	}

	public void moveEast() {
		setCurrentDirection(Direction.EAST);
		location.x += speed;
	}

	public void moveNorth() {
		// do nothing
	}

	public void moveSouth() {
		// do nothing
	}
}
