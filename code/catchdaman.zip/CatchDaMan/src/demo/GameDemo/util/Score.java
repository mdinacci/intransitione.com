package demo.GameDemo.util;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

public class Score implements Drawable {

	private static final int X_OFFSET = 10;
	private static final int Y_OFFSET = 20;
	private static final int STRING_GAP = 20;
	private int points,lifes;
	private Font font;

	public Score(int lifes, int points) {
		this.lifes = lifes;
		this.points = points;
		font = new Font("SansSerif", Font.BOLD, 18);
	}

	public void incrementPoints(int points) {
		this.points += points;
	}
	
	public void decrementPoints(int points) {
		this.points -= points;
	}
	
	public void incrementLifes(int lifes) {
		this.lifes += lifes;
	}
	
	public void decrementLifes(int lifes) {
		this.lifes -= lifes;
	}

	public int getLifes() {
		return lifes;
	}

	public void setLifes(int lifes) {
		this.lifes = lifes;
	}

	public int getPoints() {
		return points;
	}

	public void setPoints(int points) {
		this.points = points;
	}

	public void draw(Graphics g) {
		Color oldColor = g.getColor();
		g.setColor(Color.BLACK);
		g.setFont(font);
		g.drawString("Score: " + points, X_OFFSET, Y_OFFSET);
		g.drawString("Lifes: " + lifes, X_OFFSET, Y_OFFSET + STRING_GAP);
		g.setColor(oldColor);
	}
}
