The android_cookbook folder contain the "recipes" I've written for the Android Cookbook book.

The MovieSuggestions folder contains a simple Android app that I made a couple of years ago and it's still available
on the Google Play Store although I stopped working on it as soon after I released it.

