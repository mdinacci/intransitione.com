/**
 * Copyright (C) 2006 Vega Technologies SAS. All Rights Reserved.
 *
 * Project: x-forge
 */
package com.sample.math;

import net.jcip.annotations.Immutable;

/**
 * This class represents a Range. 
 * It has been completely rewritten to use generic types.
 * It is also immutable in order to be thread-safe, so don't add any setters please.
 *  
 * @author Marco Dinacci <marco.dinacci@vegatechnologies.fr>
 */
@Immutable
public class Range <T extends Number> {
	
	private final T min; 
	private final T max; 
	
	public static final Range<? extends Number> ZERO_RANGE = new Range<Integer>(0,0);
	
	/**
	 * Instantiate a new Range class.
	 * 
	 * @param min the min of the range
	 * @param max the max of the range
	 */
	public Range(T min, T max) {
		super();
		this.min = min;
		this.max = max;
	}

	/**
	 * Get the minimum value of the range.
	 * 
	 * @return the min of the range.
	 */
	public final T getMin () {
		return min;
	}

	/**
	 * Get the maximum value of the range.
	 * 
	 * @return the max of the range
	 */
	public final T getMax () {
		return max;
	}
	
	/**
	 * Get a String representation of the range
	 */
	public final String toString() {
		return min + "," + max;
	}

	/**
	 * Check whether the Number passed as argument is in the Range.
	 * Extremes are included.
	 * 
	 * It uses inRangeInclusive(Double) to perform the comparison !
	 * 
	 * @param n The number to check.
	 * @see #inRangeInclusive(Double)
	 * @return boolean Whether the parameter is in the current range.
	 */
	public boolean inRangeInclusive(T n) {
		return inRangeInclusive(n.doubleValue());
	}

	/**
	 * Check whether the Number passed as argument is in the Range.
	 * Extremes are included.
	 * 
	 * The class argument must be a child of the Number class.
	 * Pass <code>Integer.class</code> for instance if you want to check in the
	 * integer range.
	 * 
	 * @param n
	 * @param clazz
	 * @return boolean whether the given number is in the range
	 * 
	 */
	public boolean inRangeInclusive(T n, Class<? extends T> clazz) {
		boolean result = false;
		
		if(Integer.class.isAssignableFrom(clazz))
			result = inRangeInclusive(n.intValue());
		else if(Double.class.isAssignableFrom(clazz))
			result = inRangeInclusive(n.doubleValue());
		else if(Float.class.isAssignableFrom(clazz))
			result = inRangeInclusive(n.floatValue());
		else if(Long.class.isAssignableFrom(clazz))
			result = inRangeInclusive(n.longValue());
		
		
		return result;
	}
	
	/**
	 * Check whether the Double passed as argument is in the Range.
	 * Extremes are included.
	 * 
	 * @param n The number to check.
	 * @return boolean Whether the parameter is in the current range.
	 */
	private boolean inRangeInclusive(Long n) {
		return n >= min.longValue() &&
			n <= max.longValue();
	}
	
	/**
	 * Check whether the Double passed as argument is in the Range.
	 * Extremes are included.
	 * 
	 * @param n The number to check.
	 * @return boolean Whether the parameter is in the current range.
	 */
	private boolean inRangeInclusive(Float n) {
		return n >= min.floatValue() &&
			n <= max.floatValue();
	}
	
	/**
	 * Check whether the Double passed as argument is in the Range.
	 * Extremes are included.
	 * 
	 * @param n The number to check.
	 * @return boolean Whether the parameter is in the current range.
	 */
	private boolean inRangeInclusive(Double n) {
		return n >= min.doubleValue() &&
			n <= max.doubleValue();
	}
	
	/**
	 * Check whether the Integer passed as argument is in the Range.
	 * Extremes are included.
	 * 
	 * @param n The number to check.
	 * @return boolean Whether the parameter is in the current range.
	 */
	private boolean inRangeInclusive(Integer n) {
		return n >= min.intValue() &&
			n <= max.intValue();
	}
	
	/**
	 * Checks whether the given range is partially included in the current range.
	 * Note that the check is performed using integer values !.
	 *  
	 * @param incidenceRange
	 * @return boolean
	 */
	public boolean partiallyInclude(Range<T> range, Class<T> clazz) {
		boolean result = false;
		
		if(Double.class.isAssignableFrom(clazz)) 
			result = (range.max.doubleValue() < max.doubleValue() && range.max.doubleValue() > min.doubleValue() ||
				range.min.doubleValue() > min.doubleValue() && range.min.doubleValue() < max.doubleValue());
		else if(Integer.class.isAssignableFrom(clazz)) 
			result = (range.max.intValue() < max.intValue() && range.max.intValue() > min.intValue() ||
					range.min.intValue() > min.intValue() && range.min.intValue() < max.intValue());
		else if(Float.class.isAssignableFrom(clazz))
			result = (range.max.floatValue() < max.floatValue() && range.max.floatValue() > min.floatValue() ||
					range.min.floatValue() > min.floatValue() && range.min.floatValue() < max.floatValue());
		else if(Long.class.isAssignableFrom(clazz))
			result = (range.max.longValue() < max.longValue() && range.max.longValue() > min.longValue() ||
					range.min.longValue() > min.longValue() && range.min.longValue() < max.longValue());
		
		return result;
	}
}
