package com.sample.math;

import net.jcip.annotations.Immutable;

/**
 * Complex number representation.
 * 
 * @author Marco Dinacci <marco.dinacci@vegatechnologies.fr>
 */
@Immutable
public class ComplexNumber {

    private final double realPart, imaginaryPart;
    
    public ComplexNumber(double realPart, double imaginaryPart) {
        this.realPart = realPart;
        this.imaginaryPart = imaginaryPart;
    }
    
    public String toString() {
        return "(r="+realPart+"; i="+imaginaryPart+")";
    }

    public double getRealPart() {
        return realPart;
    }

    public double getImaginaryPart() {
        return imaginaryPart;
    }

    public double getMagnitude() {
        return Math.sqrt(realPart * realPart + imaginaryPart * imaginaryPart);
    }
    
    public double getPhase() {
    	double phase = 0;
        if (realPart != 0.0 || imaginaryPart != 0.0) // <=> magnitude != 0.0
            phase = Math.atan2(imaginaryPart, realPart);
        
        return phase;
    }
    
    public ComplexNumber getConjugate() {
    	return new ComplexNumber(getRealPart(), -getImaginaryPart());
    }
}
