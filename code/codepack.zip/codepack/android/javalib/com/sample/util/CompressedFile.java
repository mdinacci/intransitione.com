/**
 * Copyright 2007-2008 VEGA Technologies SAS
 * All rights reserved
 *
 * Project: vegajlib
 */
package com.sample.util;

import net.jcip.annotations.GuardedBy;
import net.jcip.annotations.ThreadSafe;

import java.io.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/**
 * Create a compressed (zip, or jar) file.
 * This class its way easier to use then {@link ZipFile} 
 * and it's thread-safe.
 * 
 * @author Marco Dinacci <marco.dinacci@vegatechnologies.fr>
 * @see ZipFile
 * 
 */
@ThreadSafe
public class CompressedFile {

	// The output stream used to write the file
	private ZipOutputStream zout;
	
	// The lock object
	private Object lock;
	
	// Parent dir of the compressed file
	@GuardedBy("lock")
	private File parentDir;
	
	// Length of the parent dir, stored only to make the class more easily thread-safe
	@GuardedBy("lock")
	private int parentDirAbsoluteLength;
	
	
	public class CompressedFileException extends Exception {
		public CompressedFileException(Exception e) {
			super(e);
		}
	}

	
	/**
	 * Create a new compressed file 
	 * 
	 * @param compressedFile Path where the file will be saved
	 * @throws CompressedFileException
	 */
	public CompressedFile(String compressedFile) throws CompressedFileException {
		try {
			zout = new ZipOutputStream(new FileOutputStream(compressedFile));
		} catch (FileNotFoundException e) {
			throw new CompressedFileException(e);
		}
	}
	
	/**
	 * Add a directory to the compressed file.
	 * Directories are always added to the root of the compressed file (/).
	 * 
	 * It does nothing if the parameter is not a directory.
	 * 
	 * @param dir The directory to add.
	 * @throws CompressedFileException
	 */
	public void addDirectory(File dir) throws CompressedFileException  {
		if(! dir.isDirectory()) {
			return;
		}
		
		synchronized (lock) {
			if(parentDir == null) {
				parentDir = dir;
				parentDirAbsoluteLength = parentDir.getAbsolutePath().length();
			}
		}
		
		try {
			for (File file : dir.listFiles()) {
				String absPath = file.getAbsolutePath();
				String relativePath = absPath.substring(parentDirAbsoluteLength+1,absPath.length());
				
				if(file.isDirectory()) {
					addDirectory(file);
				} else { 
					// use relativePath because files must be packaged
					// from the root of the zip file.
					addFileToZip(file, relativePath);
				}
			}
		} catch(Exception e) {
			throw new CompressedFileException(e);
		}
	}
	
	/**
	 * Add a file to the compressed file
	 * 
	 * @param absolutePath The path in the filesystem
	 * @param relativePath The path from the beginning of the compressed file
	 * @throws Exception
	 */
	public void addFileToZip(File absolutePath, String relativePath) throws Exception {
		ZipEntry ze = new ZipEntry(relativePath);
		writeZipEntry(ze, new FileInputStream(absolutePath));
	}
	
	/**
	 * Save the file. Remember to call it !
	 * 
	 * @throws CompressedFileException
	 */
	@GuardedBy("this")
	synchronized public void saveFile() throws CompressedFileException {
		try {
			zout.flush();
			zout.close();
		} catch (IOException e) {
			throw new CompressedFileException(e);
		}
	}
	
	/*
	 * Write a zip entry in the zip file
	 */
	@GuardedBy("this")
	synchronized private void writeZipEntry(ZipEntry ze, InputStream in) throws Exception {
		ze.setTime(System.currentTimeMillis());
		zout.putNextEntry(ze);
		byte[] buf = new byte[4096];
		int len;
		while ((len = in.read(buf)) > 0) {
			zout.write(buf, 0, len);
		}
		in.close();
	}
}
