/**
 * Copyright 2007-2008 VEGA Technologies SAS
 * All rights reserved
 *
 * Project: vegajlib
 */

package com.sample.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Properties;

/**
 * Provides a central way to manage simple property files in an application.
 * It mimics the Properties API in order to avoid changing as few as code possible
 * in code that is already using the <code>Properties</code> class.
 * 
 * It's easier to use with "import static" (Java >= 1.5).
 * Ex.
 * 
 * import static com.sample.util.GlobalProperties.propertiesInstance;
 * ...
 * propertiesInstance.getProperty("toto");
 * ...
 * 
 * @author Marco Dinacci <marco.dinacci@vegatechnologies.fr>
 */
public class GlobalProperties {
	
	public static final GlobalProperties propertiesInstance = new GlobalProperties();
	private Properties globalProperties ;

	private GlobalProperties() {
		globalProperties = new Properties();
	}
	
	/**
	 * Add the properties in the property file in argument to the 
	 * global property list.
	 * 
	 * @param propertyFile
	 */
	public void load(String propertyFile) {
		Properties properties = new Properties();
		try {
			properties.load(getClass().getResourceAsStream(propertyFile));
		} catch (IOException e) {
			throw new IllegalArgumentException("Can't read global properties file: " + propertyFile);
		}
		
		mergeProperties(properties, globalProperties);
	}

	/**
	 * Add the properties from the <code>InputStream</code> to
	 * the global property list.
	 *  
	 * @param inStream
	 * @throws IOException
	 */
	public void load(InputStream inStream) throws IOException {
		Properties properties = new Properties();
		properties.load(inStream);
		
		mergeProperties(properties, globalProperties);
	}
	
	/**
	 * Get a property by name
	 * 
	 * @param propertyName
	 * @return
	 */
	public String getProperty(String propertyName) {
		return globalProperties.getProperty(propertyName);
	}
	
	/**
	 * 
	 * @param propertyName
	 * @param defaultValue 
	 * @return
	 */
	public Double getPropertyAsDouble(String propertyName, String defaultValue) {
		return Double.valueOf(globalProperties.getProperty(propertyName,defaultValue));
	}
	
	/**
	 * Returns the property indicated by the key passed as first argument
	 * or the default value otherwise
	 * 
	 * @param propertyName
	 * @param defaultValue
	 * @return
	 */
	public String getProperty(String propertyName, String defaultValue) {
		return globalProperties.getProperty(propertyName, defaultValue);
	}
	
	/*
	 * Merge a property file into the global one
	 */
	private void mergeProperties(Properties properties,
			Properties globalProperties) {
		
		Enumeration<?> names = properties.propertyNames();

		while (names.hasMoreElements()) {
			String name = (String) names.nextElement();
			globalProperties.setProperty(name, properties.getProperty(name));
		}
	}
}