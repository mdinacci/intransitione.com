/**
 * Copyright 2007-2008 VEGA Technologies SAS
 * All rights reserved
 *
 * Project: vegajlib
 */
package com.sample.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

import net.jcip.annotations.Immutable;

/**
 * An iterable string which is splitted given a user-defined pattern.
 * 
 * It simplifies a bit the usage of the <code>Scanner</code> class which doesn't provide utility methods 
 * to convert the tokens to arrays.
 *
 * @author Marco Dinacci <marco.dinacci@vegatechnologies.fr>
 */
@Immutable
public class PatternDelimitedString implements Iterable<String> {

	private final String rawString;
	private final String pattern;
	
	/**
	 * Construct a new <code>PatternDelimitedString</code>
	 * 
	 * @param rawString the original String to split.
	 * @param pattern a pattern following the Java regular expression conventions
	 */
	public PatternDelimitedString(String rawString, String pattern) {
		this.rawString = rawString;
		this.pattern = pattern;
	}
	
	/**
	 * Construct a new <code>PatternDelimitedString</code>
	 * 
	 * @param rawString the original String to split.
	 * @param pattern a pattern following the Java regular expression conventions
	 */
	public PatternDelimitedString(String rawString, Pattern pattern) {
		this(rawString, pattern.pattern());
	}

	/**
	 * Returns an iterator over the token of the string.
	 *
	 * @return an Iterator<String>
	 */
	public Iterator<String> iterator() {
		return stringToList(rawString, pattern).iterator();
	}
	
	/**
	 * Returns the splitted string as an array of String
	 * 
	 * @return a String array
	 */
	public String[] toStringArray() {
		List<String> list = stringToList(rawString, pattern);
		return list.toArray(new String[list.size()]);
	}

	/**
	 * Returns the tokens as an array of int.
	 * The method doesn't do any attempt to catch an eventual NumberFormatException !! 
	 * 
	 * @return an array of ints
	 */
	public int[] toIntArray() {
		List<String> strings = stringToList(rawString, pattern);
		int[] arr = new int[strings.size()];
		for (int i = 0; i < arr.length; i++) {
			arr[i] = Integer.valueOf(strings.get(i));
		}
		
		return arr;
	}
	
	/**
	 * Transforms the raw string in a list of strings
	 * 
	 * @param s
	 * @param pattern
	 * @return a list of String
	 */
	public static List<String> stringToList(String s, String pattern) {
		List<String> strings = new ArrayList<String>();

		if(s != null && pattern != null) {
			if(s.indexOf(pattern) != -1) {
				Scanner scanner = new Scanner(s).useDelimiter(pattern);
				
				while(scanner.hasNext())
					strings.add(scanner.next());
			} else
				strings.add(s);
		}

		return strings;
	}
}