/**
 * Copyright (C) 2003-2007 Vega Technologies SAS. All Rights Reserved.
 *
 * Project: vegajlib
 */

package com.sample.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Collection of File utilities.
 * 
 * @author Marco Dinacci <marco.dinacci@vegatechnologies.fr>
 * @version $Id: FileUtilities.java,v 1.1 2007/08/30 12:34:04 mdinacci Exp $
 */
public class FileUtilities {
    
    /**
     * Get all files in a directory matching the regular expression pattern given.
     * Can recurse inside sub-directories if last parameter is true.
     * 
     * @param inputUrl The directory where to start the search.
     * @param pattern The regular expression pattern.
     * @param recursive Whether the search must be carried in sub-directories or not.
     * @return a {@link Set} containing all the matching files. 
     */
    public static Set<File> getFilesInDirMatchingPattern(File inputUrl, Pattern pattern, boolean recursive) {
        assert (inputUrl.isDirectory());

        Set<File> matchingFiles = new HashSet<File>();
        
        File[] fileList = inputUrl.listFiles();
        for (File file : fileList) {
            if(file.isDirectory() && recursive)
                matchingFiles.addAll(getFilesInDirMatchingPattern(file, pattern, true));
            else if(file.isFile() && pattern.matcher(file.getName()).matches())
                matchingFiles.add(file);
        }

        return matchingFiles;
    }
    
    /**
     * Recursively copy a directory and its content. 
     * 
     * @param inputDir The source directory 
     * @param outputDir The destination directory
     * @throws IOException
     */
    public static void copyDirectory(File inputDir, File outputDir) throws IOException {
        if (inputDir.isDirectory()) {
            if (!outputDir.exists())
                outputDir.mkdir();
    
            String[] files = inputDir.list();
            for (String file : files) {
                copyDirectory(new File(inputDir, file), new File(outputDir, file));
            }
        } else {
            copyFile(inputDir, outputDir);
        }
    }
    
    /**
     * Copy a file from a position to another.
     * 
     * @param inputFile The source file
     * @param outputFile The destination file
     */
    public static void copyFile(File inputFile, File outputFile) throws IOException {
        InputStream in = new FileInputStream(inputFile);
        OutputStream out = new FileOutputStream(outputFile);
    
        transfer(in, out);
    }
    
    /**
     * Transfer data from an <code>InputStream</code>to an <code>OutputStream</code>.
     * 
     * @param in
     * @param out
     * @throws IOException
     */
    public static void transfer(InputStream in, OutputStream out) throws IOException {
    	FileUtilities.transfer(in, out, 4096);
    }
    
    /**
     * Transfer data from an <code>InputStream</code>to an <code>OutputStream</code>.
     * 
     * @param in
     * @param out
     * @throws IOException
     */
    public static void transfer(InputStream in, OutputStream out, int bufSize) throws IOException {
    	byte[] buf = new byte[bufSize];
    	int len;
    	while ((len = in.read(buf)) > 0) {
    		out.write(buf, 0, len);
    	}
    	
    	in.close();
    	out.close();
    }
}
