/**
 * Copyright 2007-2008 VEGA Technologies SAS
 * All rights reserved
 *
 * Project: vegajlib
 */
package com.sample.util.jar;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import net.jcip.annotations.Immutable;

/**
 * Utility class to deal with jar files.
 * 
 * @author Marco Dinacci <marco.dinacci@vegatechnologies.fr>
 */
@Immutable
public class JarUtilities {
    /**
     * Extract the files from the Jar and put it in a temp directory
     * 
     * Files must have a similar path: file://path/to/jar/file.jar!/path/to/resource/in/jar
     * 
     * @param files The files to extract. Paths are relative to the jar file.
     * @throws IOException 
     */
    public static File[] extractFilesFromJarTo(File[] files, String dirName) throws IOException {
    	List<File> extractedFiles = new ArrayList<File>();
    	File dir = new File(dirName);
    	if(!dir.exists())
    		throw new IllegalArgumentException("Cannot extract files to not existing directory !");
    	
        for (File file : files) {
            // get the jar file from the file path
            String jarPath = file.getPath();
            extractedFiles.add(extractResourceFromJarToDir(jarPath, dir));
        }
        
        return (File[]) extractedFiles.toArray(new File[extractedFiles.size()]);
    }


	/**
     * An example of a URL for a resource in a Jar follows this syntax:
     * file://path/to/jar/file.jar!/path/to/resource/in/jar
     *
     * @param fullPath String of the path of the resource in the jar.
     * @return The extracted file.
	 * @throws IOException 
     * @throws IllegalArgumentException Thrown if the format string is wrong.
     */
    public static File extractResourceFromJarToDir(String fullPath, File destDir) throws IOException {
        int startIndex;

		if(fullPath.startsWith("file://"))
			startIndex = 6;
		else if(fullPath.startsWith("file:/") || fullPath.startsWith("file:\\"))
			startIndex = 5;
		else
            throw new IllegalArgumentException("Path must start with 'file:/'");

        final char SEPARATOR = '!';
		
        String jarPath = fullPath.substring(startIndex, fullPath.indexOf(SEPARATOR));
        String resourcePath = fullPath.substring(fullPath.indexOf(SEPARATOR)+2, fullPath.length());
 
        JarResources resources = new JarResources(jarPath);
        byte[] resourceBytes = resources.getResource(resourcePath);

        File destFile = new File(destDir + System.getProperty("file.separator") + resourcePath);
        
        FileOutputStream fileStream = new FileOutputStream(destFile);
        fileStream.write(resourceBytes);
        fileStream.flush();
        fileStream.close();
        
		return destFile;
    }
}
