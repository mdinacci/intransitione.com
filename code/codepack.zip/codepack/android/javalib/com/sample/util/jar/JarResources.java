/**
 * Copyright (C) 2006-2008 Vega Technologies SAS. All Rights Reserved.
 *
 * Project: vegajlib
 */

package com.sample.util.jar;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;

import net.jcip.annotations.ThreadSafe;

/**
 * JarResources maps all resources included in a Zip or Jar file.
 *
 * @author Marco Dinacci <marco.dinacci@vegatechnologies.fr>
 */
@ThreadSafe
public class JarResources {
    private HashMap<String, Integer> entrySizes = new HashMap<String, Integer>();
    private final String jarFileName;

    /**
    * Creates a JarResources. 
    * @param jarFileName a jar or zip file
    */
    public JarResources(String jarFileName) {
        this.jarFileName = jarFileName;
    }

    /**
     * Extracts a jar resource as a byte array. This method opens the
     * file every time is called, it is done for purpose in order to deal with
     * big jars without incurring in a performance hit.
     *
     * @param name a resource name.
     *
     * @return The resource as a byte array
     *
     * @throws IOException
     */
    public byte[] getResource(String name) throws IOException {
    	// the array to return
    	byte[] bytes = null;
    	
        // optimization: lazily initialize size of every resource
        if (entrySizes.size() == 0) {
            ZipFile zf = new ZipFile(jarFileName);
            Enumeration e = zf.entries();
            while (e.hasMoreElements()) {
                ZipEntry ze = (ZipEntry)e.nextElement();
                entrySizes.put(ze.getName(), new Integer((int)ze.getSize()));
            }
            zf.close();
        }

        // extract resource
        FileInputStream fis = new FileInputStream(jarFileName);
        ZipInputStream zis = new ZipInputStream(new BufferedInputStream(fis));
        ZipEntry ze = null;
        
        while ((ze = zis.getNextEntry()) != null) {
            if (ze.getName().equals(name)) {
            	 // FIXME will cause a problem if the file is very big
                int size = (int)ze.getSize(); 

                // -1 means unknown size.
                // it can happens only if a file is added after the first time
                // the jar has been read.
                if (size == -1) {
                    size = entrySizes.get(ze.getName());
                }

                bytes = new byte[size];
                int rb = 0;
                int chunk = 0;
                while ((size - rb) > 0) {
                    chunk = zis.read(bytes, rb, size - rb);
                    if (chunk == -1) {
                        break;
                    }
                    rb += chunk;
                }
                break;
            }
        }
        
        return bytes;
    }
}
