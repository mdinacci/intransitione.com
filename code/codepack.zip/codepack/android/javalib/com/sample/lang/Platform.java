/**
 * Copyright 2007-2008 VEGA Technologies SAS
 * All rights reserved
 *
 * Project: vegajlib
 */
package com.sample.lang;

/**
 * Utilities to detect the system platform
 *
 * @author unknown
 */
public class Platform {

	public static boolean isWindowsPlatform () {
		return System.getProperty ("os.name").toLowerCase ().indexOf ("win") != -1;
	}

	public static boolean isXPlatform () {
		return (isWindowsPlatform () == false) && (isMacPlatform () == false);
	}

	public static boolean isMacPlatform () {
		return System.getProperty ("os.name").toLowerCase ().indexOf ("mac") != -1;
	}

	public static boolean isSolarisPlatform () {
		return System.getProperty ("os.name").toLowerCase ().indexOf ("solaris") != -1;
	}

	public static boolean isLinuxPlatform () {
		return System.getProperty ("os.name").toLowerCase ().indexOf ("linux") != -1;
	}
}
