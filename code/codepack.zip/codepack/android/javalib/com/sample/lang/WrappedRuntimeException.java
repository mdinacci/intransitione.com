/**
 * Copyright (C) 2003-2007 Vega Technologies SAS. All Rights Reserved.
 *
 * Project: vegajlib
 */

package com.sample.lang;

/**
 * The name says it all. Use it when you want to throw a RuntimeException.
 * 
 * @author Marco Dinacci <marco.dinacci@vegatechnologies.fr>
 * @version $Id: $
 */
public class WrappedRuntimeException extends RuntimeException {
	public WrappedRuntimeException(Throwable t) {
		super (t);
	}
	
	public WrappedRuntimeException(String message, Throwable t) {
		super(message, t);
	}
	
	public WrappedRuntimeException(String message) {
		super(message);
	}
}
