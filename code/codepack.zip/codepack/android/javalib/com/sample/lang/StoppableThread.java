/**
 * Copyright 2007-2008 VEGA Technologies SAS
 * All rights reserved
 *
 * Project: vegajlib
 */
package com.sample.lang;

import java.util.concurrent.atomic.AtomicBoolean;

import net.jcip.annotations.ThreadSafe;

/**
 * A StoppableThread is a "Runnable" that can be
 * suspended, resumed or stopped.
 * 
 * To use it you must:
 * <ul>
 *   <li>Extend the class</li> 
 *   <li>Override the <code>execute</code> method
 *   <li>Call start to fire up the thread. DO NOT CALL <code>run</code> !</li>
 * </ul>
 * 
 * Also, consider first using the concurrent framework provided by Java 1.5 
 * (Executor, Future etc..)
 *
 * Works only with Java >= 1.5.
 * 
 * @see Runnable
 * @see Thread
 * @see AtomicBoolean
 * @see java.lang.concurrent.* 
 * @author Marco Dinacci <marco.dinacci@gmail.com>
 */
@ThreadSafe
public abstract class StoppableThread implements Runnable {
	
	private AtomicBoolean suspended = new AtomicBoolean(false);
	private AtomicBoolean stopped = new AtomicBoolean(false);
	private AtomicBoolean started = new AtomicBoolean(false);
	
	/* thread name; passed as argument otherwise "StoppableThread-counter" */
	private String name;
	
	/* anonymous (no name) instance counter */
	private static int counter;
	
	/* sleep time */
	protected int sleepTime;
	
	/**
	 * Construct an instance of the StoppableThread class
	 * that will sleep for the given time.
	 * 
	 * @param sleepTime
	 */
	public StoppableThread(int sleepTime) {
		this(sleepTime, "StoppableThread-" + counter++);
	}
	
	/**
	 * Construct an instance of the StoppableThread class
	 * with the given name and with a default sleep time of 100ms.
	 */
	public StoppableThread(String name) {
		this(100, name);
	}
	
	/**
	 * Construct an instance of the StoppableThread class
	 * with a default sleep time of 100ms.
	 */
	public StoppableThread() {
		this(100);
	}

	/**
	 * Construct an instance of the StoppableThread class
	 * with the given name and that will sleep for the given time.
	 * 
	 * @param sleepTime
	 * @param name
	 */
	public StoppableThread(int sleepTime, String name) {
		this.sleepTime = sleepTime;
		this.name = name;
	}
	
	/** 
	 * Provide the application logic for this thread.
	 * Must be overridden by subclasses.
	 */
	protected abstract void execute();
	
	/**
	 * Returns the started status of this thread
	 * @return boolean whether the thread is started or not
	 */
	public boolean isStarted() {
		return started.get();
	}

	/**
	 * Returns the stopped status of this thread
	 * @return boolean whether the thread is stopped or not
	 */
	public boolean isStopped() {
		return stopped.get();
	}

	/**
	 * Returns the suspended status of this thread
	 * @return boolean whether the thread is suspended or not
	 */
	public boolean isSuspended() {
		return suspended.get();
	}
	
	/**
	 * Returns the name of this thread.
	 * 
	 * @return name
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Execute this thread.
	 * Do not call it directly but use the start method instead.
	 * It is public because it is inherited from the interface.
	 * @see StoppableThread#start()
	 */
	public void run() {
		started.set(true);
		
		while (!stopped.get()) {
			if (!suspended.get()) {
				execute();
			}
			Thread.yield();
			try {
				Thread.sleep(sleepTime);
			} catch (InterruptedException e) {}
		}
	}
	
	/**
	 * Simulate the usage of the Thread class.
	 * Use this method to launch the Thread instead of 
	 * directly using the run method.
	 * @see StoppableThread#run()
	 */
	public void start() {
		run();
	}
	
	/**
	 * Suspend the thread.
	 */
	public void suspend() {
		suspended.set(true);
	}
	
	/**
	 * Resume the thread.
	 */
	public void resume() {
		suspended.set(false);
	}
	
	/**
	 * Stop the thread.
	 */
	public void stop() {
		suspended.set(true);
		stopped.set(true);
		started.set(false);
	}	
}