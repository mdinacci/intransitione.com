/**
 * Copyright (C) 2003-2007 Vega Technologies SAS. All Rights Reserved.
 *
 * Project: vegalib
 */
package com.sample.crypto;

/**
 * @author Marco Dinacci <marco.dinacci@vegatechnologies.fr>
 * @version $Id: TextCipher.java,v 1.1 2006/09/13 11:29:49 mdinacci Exp $
 */
public interface TextCipher extends Cipher {
	public String getEncryptedText();
}
