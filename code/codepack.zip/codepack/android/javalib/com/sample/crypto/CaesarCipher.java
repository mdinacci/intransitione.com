/**
 * Copyright (C) 2006-2008 Vega Technologies SAS. All Rights Reserved.
 *
 * Project: vegalib
 */
package com.sample.crypto;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.CharBuffer;

import net.jcip.annotations.NotThreadSafe;

/**
 * Implement the Caesar Cipher.
 * 
 * <p>It is supposed to be used to encrypt small files (the size of 
 * the internal buffer is only 1MB).</p>
 * 
 * <p>Please note that the input file is completely read in memory and
 * that only ASCII files are supported !</p>
 * 
 * <p>Typical usage scenario: <br>
 *    CaesarCipher cp = new CaesarCipher(8);
 *    cp.setInputFile(new File(myfile));
 *    cp.encrypt(); // or cp.decrypt()
 *    cp.saveOutputFileTo
 *    
 * @author Marco Dinacci <marco.dinacci@vegatechnologies.fr>
 * @version $Id: CaesarCipher.java,v 1.1 2006/09/13 11:29:49 mdinacci Exp $
 * @see {@link http://en.wikipedia.org/wiki/Caesar_cipher}
 */
@NotThreadSafe
public class CaesarCipher implements TextCipher {

	// cripto key
	private int key;
	
	private FileReader reader;
	private CharBuffer buffer;
	
	private String encryptedText;
	private String decryptedText;
	
	private static final String ALPHANUM = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
	protected static int MAX_CAPACITY = 1024*1024;

	public CaesarCipher(int key) {
		this.key = key;
		
		buffer = CharBuffer.allocate(MAX_CAPACITY);
	}
	
	/**
	 * Utility method to return a scrambled char.
	 * 
	 * @param c The character to scramble.
	 * @param k The key to used for scrambling.
	 * @return The scrambled char.
	 */
	public static char scrambleCharWithKey(char c, int k) {
		return rotate(c,k);
	}

	/* Get next character from stream */
	private char getNextChar() {
		char ch = ' '; 
		try {
			ch = (char) reader.read(); 
		} catch (IOException e) {
			System.out.println("Exception reading character");
		}
		return ch;
	}
	
	/* Rotate the character */
	private static char rotate(char c, int key) { 
		int i = 0;
		while (i < ALPHANUM.length()) {
			// extra length because key might be negative
			if (c == ALPHANUM.charAt(i))
				return ALPHANUM.charAt((i + key + ALPHANUM.length()) % ALPHANUM.length());
			i++;
		}
		return c;
	}
	
	/*
	 * Get the valid string (actual characters read) from a CharBuffer.
	 * Note that in order to do this the buffer position is rewinded.
	 */
	private String getValidTextFromBuffer(CharBuffer buffer) {
		int mark = buffer.position();
		buffer.rewind();
		
		return buffer.subSequence(0,mark).toString();
	}
	
	/* Performs the actual (en|de)coding */
	protected void scramble(int k) {
		char c;
		while ((byte) (c = getNextChar()) != -1) {
			c = rotate(c, k);
			buffer.put(c);
		}
	}

	/*
	 * (non-Javadoc)
	 * @see com.sample.crypto.Cipher#encrypt()
	 */
	public void encrypt() {
		scramble(key);
		
		encryptedText = getValidTextFromBuffer(buffer);
	}
	
	/*
	 * (non-Javadoc)
	 * @see com.sample.crypto.Cipher#decrypt()
	 */
	public void decrypt() {
		scramble(-key);
		
		decryptedText = getValidTextFromBuffer(buffer);
	}

	/**
	 * Set the text file containing the text to cript.
	 * @param inputFile The plain file to read.
	 * @throws FileNotFoundException In case file is not found.
	 */
	public void setInputFile(File inputFile) throws FileNotFoundException {
		reader = new FileReader(inputFile);
		buffer.clear();
	}

	/**
	 * Save encrypted file to disk.
	 * @param file The encrypted file
	 * @throws IOException In case of error writing the encrypted file 
	 */
	public void saveOutputFile(File file) throws IOException {
		FileWriter writer = new FileWriter(file);

		if(encryptedText != null)
			writer.write(encryptedText);
		else if(decryptedText != null)
			writer.write(decryptedText);
		
		writer.close();
	}

    /**
     * Return the decrypted text or null if no decryption has been performed.
     * @return The decrypted String.
     */
    public String getDecryptedText() {
        return decryptedText;
    }
    
	/*
	 *  (non-Javadoc)
	 * @see com.sample.crypto.TextCipher#getEncryptedText()
	 */
	public String getEncryptedText() {
		return encryptedText;
	}
	
	/*
	 * Provide a main to use this class as a command-line tool.
	 * Usage:
	 *     $ java CaesarCipher [e|d] <key> <inputfile> <ouputfile>
	 *     
	 * First parameter is the action. 
	 * 		"e" -> encrypt
	 * 		"d" -> decrypt
	 * Second parameter is the key. 
	 * 		Must be a positive number, it is no necessary too be big (1-50)
	 * Third parameter is the file to read the input from.
	 * Fourth parameter is the file where to save the result.
	 */
	public static void main(String[] args) throws IOException {
		if(args.length < 4)
			throw new IllegalArgumentException("Not enough parameters");
		
		String actionName = args[0];
		int key = new Integer(args[1]);
		File inputFile = new File(args[1]);
		File outputFile = new File(args[2]);
		
		CaesarCipher cipher = new CaesarCipher(key);
		cipher.setInputFile(inputFile);
		
		if(actionName.equalsIgnoreCase("e")) {
			cipher.encrypt();
		} else if(actionName.equalsIgnoreCase("d")) {
			cipher.decrypt();
		}
		
		cipher.saveOutputFile(outputFile);
	}
}
