/**
 * Copyright 2007-2008 VEGA Technologies SAS
 * All rights reserved
 *
 * Project: vegajlib
 */
package com.sample.gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JComponent;
import javax.swing.SwingConstants;

import net.jcip.annotations.NotThreadSafe;


/**
 * A output widget used to display a colormap, derived from the
 * javax.swing.JComponent, and can be used in any context that calls for a
 * JComponent.
 *
 * @author Dennis Sigel
 * @author Marco Dinacci <marco.dinacci@vegatechnologies.fr>
 * @see ColorTable
 */
@NotThreadSafe
public class ColorBar extends JComponent {

    protected int componentWidth;
    protected int componentHeight;
    protected int _direction;

    protected byte[][] _lut;

    protected int _redIndex;
    protected int _greenIndex;
    protected int _blueIndex;
    
    public ColorBar(ColorBar bar) {
    	componentHeight = bar.componentHeight;
    	componentWidth = bar.componentWidth;
    	_lut = bar._lut;
    	_redIndex = bar._redIndex;
    	_greenIndex = bar._greenIndex;
    	_blueIndex = bar._blueIndex;
    	_direction = bar._direction;
    	
    }
    
    public ColorBar(ColorTable table) {
    	this (table, SwingConstants.HORIZONTAL);
    }
    
    public ColorBar(ColorTable table, int direction) {
    	_lut = table.getLookupTable();
    	_redIndex = 0;
    	_greenIndex = _lut.length == 3 ? 1 : 0;
    	_blueIndex = _lut.length == 3 ? 2 : 0;
    }

    public synchronized void setLut(byte[][] newlut) {
    	_lut = newlut;
    	_redIndex = 0;
    	_greenIndex = _lut.length == 3 ? 1 : 0;
    	_blueIndex = _lut.length == 3 ? 2 : 0;
        repaint();
    }

    /*
     *  (non-Javadoc)
     * @see java.awt.Component#setBounds(int, int, int, int)
     */
    @Override
    public void setBounds(int x, int y, int width, int height) {
    	componentWidth  = width;
    	componentHeight = height;
    	super.setBounds(x, y, width, height);
    }
    
	public Dimension getPreferredSize() {
		if (_direction == SwingConstants.HORIZONTAL) {
			return new Dimension(150, 20);
		} else {
			return new Dimension(20, 150);
		}
	}

    /*
     *  (non-Javadoc)
     * @see javax.swing.JComponent#paintComponent(java.awt.Graphics)
     */
    public synchronized void paintComponent(Graphics g) {

        Graphics2D g2D = null;
        if (g instanceof Graphics2D) {
            g2D = (Graphics2D)g;
        } else {
            return;
        }

        g2D.setColor(getBackground());
        g2D.fillRect(0, 0, componentWidth, componentHeight);

        if ( _direction == SwingConstants.HORIZONTAL ) {
            float slope = (float)componentWidth / 255.0F;

            for ( int n = 0; n < _lut[0].length; n++ ) {
                int w = componentWidth - (int)((float)n*slope);
                int v = _lut[0].length - n - 1;
                int red   = _lut[_redIndex][v]&0xFF;
                int green = _lut[_greenIndex][v]&0xFF;
                int blue  = _lut[_blueIndex][v]&0xFF;
                g.setColor(new Color(red, green, blue));
                g.fillRect(0, 0, w, componentHeight);
            }
        } else if ( _direction == SwingConstants.VERTICAL ) {
            float slope = (float)componentHeight / 255.0F;

            for ( int n = 0; n < _lut[0].length; n++ ) {
                int h = componentHeight - (int)((float)n*slope);
                int red   = _lut[_redIndex][n]&0xFF;
                int green = _lut[_greenIndex][n]&0xFF;
                int blue  = _lut[_blueIndex][n]&0xFF;
                g.setColor(new Color(red, green, blue));
                g.fillRect(0, 0, componentWidth, h);
            }
        }
    }
}
