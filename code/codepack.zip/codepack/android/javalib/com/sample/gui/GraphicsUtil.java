/**
 * Copyright 2007-2008 VEGA Technologies SAS
 * All rights reserved
 *
 * Project: vegajlib
 */
package com.sample.gui;


import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.font.FontRenderContext;
import java.awt.font.LineMetrics;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import javax.swing.JComponent;

/**
 * Utility functions to deal with graphic-related code 
 * 
 * @author Marco Dinacci <marco.dinacci@vegatechnologies.fr>
 * @version $Id: GraphicsUtil.java,v 1.1 2006/11/13 17:07:34 mdinacci Exp $
 */
public class GraphicsUtil {

	/**
	 * Returns a <code>Point2D</code> of the position from where to start drawing a string
	 * in order to place it in the center of a component.
	 * 
	 * @param g The <code>Graphics2D</code> context
	 * @param message The message to draw
	 * @param font The font used
	 * @param component The reference component
	 * 
	 * @return a <code>Point2D</code>
	 */
	public static Point2D pointForCenteringStringOnScreen(Graphics2D g, String message, Font font, JComponent component) {
		// Measure the font and the message
		FontRenderContext frc = g.getFontRenderContext();
		Rectangle2D bounds = font.getStringBounds(message, frc);
		LineMetrics metrics = font.getLineMetrics(message, frc);
		float width = (float) bounds.getWidth();     // The width of our text
		float lineheight = metrics.getHeight();      // Total line height
		float ascent = metrics.getAscent();          // Top of text to baseline

		// Now display the message centered horizontally and vertically in box
		float x0 = (float) (component.getX() + (component.getWidth() - width)/2);
		float y0 = (float) (component.getY() + (component.getHeight() - lineheight)/2 + ascent);
		
		Point2D point = new Point2D.Float(x0,y0);
		return point;
	}
}
