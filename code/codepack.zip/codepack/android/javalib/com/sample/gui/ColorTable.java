/**
 * Copyright 2005-2008 VEGA Technologies SAS
 * All rights reserved
 *
 * Project: vegajlib
 */
package com.sample.gui;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;

import net.jcip.annotations.NotThreadSafe;

/**
 * @author Marc Jambert
 */
@NotThreadSafe
public class ColorTable implements Serializable {

	private byte[][] _lut;	
	private String _name;
	
	public ColorTable(String name, byte[][] lut) {
		super();
		_name = name;
		_lut = lut;
	}
	
	public final byte[][] getLookupTable () {
		return _lut;
	}
	
	public final void setLookupTable (byte[][] lut) {
		_lut = lut;
	}
	
	public String getName () {
		return _name;
	}
	
	
    public synchronized void loadFrom(InputStream is) throws IOException, ClassNotFoundException {
        ObjectInputStream objectStream = new ObjectInputStream(is);
        _name = (String) objectStream.readObject();
        _lut = (byte[][]) objectStream.readObject();
        objectStream.close();
    }

    public synchronized void saveTo(OutputStream os) throws IOException {
        Object o = this;
        ObjectOutputStream objectStream =
            new ObjectOutputStream(os);
        objectStream.writeObject(_name);
        objectStream.writeObject(_lut);
        objectStream.close();
        os.close();
    }	
	
	public ColorTable clone(){
		byte[][] newlut = new byte[3][256];
		for (int i=0;i<3;i++){
			for (int j=0;j<256;j++)
			{
				newlut[i][j]=_lut[i][j];
			}
		}
		ColorTable newColorTable = new ColorTable(this._name,newlut); 
		return newColorTable;
	}	
}
