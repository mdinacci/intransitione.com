/**
 * Copyright 2007-2008 VEGA Technologies SAS
 * All rights reserved
 *
 * Project: vegajlib
 */
package com.sample.gui.dnd;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DragGestureEvent;
import java.awt.dnd.DragGestureListener;
import java.awt.dnd.DragGestureRecognizer;
import java.awt.dnd.DragSource;
import java.awt.dnd.DragSourceAdapter;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import net.jcip.annotations.NotThreadSafe;

/**
 * An export component for dnd operations compatible with Java 1.4,1.5,1.6 and
 * if Mister Java wants also with greater versions.
 * If Mister Apple wants it should also works on Mac.
 * 
 * You basically use it to drag a subclass of JLabel from the user interface to outside.
 * JLabels have icons, remember. 
 *
 * @author Marco Dinacci <marco.dinacci@vegatechnologies.fr>
 * @see JLabel
 * @see DataFlavor
 * @see DragSource
 */
@NotThreadSafe
public class ExportComponent extends JLabel {
	private static DataFlavor uriListFlavor;

	private String exportFile;

	static {
		try {
			uriListFlavor = new DataFlavor(
					"text/uri-list;class=java.lang.String");
		} catch (ClassNotFoundException e) { // can't happen
			throw new AssertionError("Impossible. Must have been caused by a cosmic ray...");
		}
	}

	/* Handle drag-drop to disk */
	class DragAdapter extends DragSourceAdapter implements Transferable,
			DragGestureListener {

		DragAdapter(JComponent c) {
			DragSource ds = DragSource.getDefaultDragSource();
			
			// MD: never used but it's necessary to create it...
			@SuppressWarnings("unused") DragGestureRecognizer dgr = ds.createDefaultDragGestureRecognizer(
					c, DnDConstants.ACTION_COPY, this);
		}

		// supported flavors
		private DataFlavor[] FLAVORS = new DataFlavor[] {
				DataFlavor.javaFileListFlavor, uriListFlavor };

		/*
		 * (non-Javadoc)
		 * @see java.awt.datatransfer.Transferable#getTransferData(java.awt.datatransfer.DataFlavor)
		 */
		public Object getTransferData(DataFlavor flavor)
				throws UnsupportedFlavorException, java.io.IOException {
			File file = new File(exportFile);
			if (flavor.equals(DataFlavor.javaFileListFlavor)) {
				List<File> data = new ArrayList<File>();
				data.add(file);
				return data;
			} else if (flavor.equals(uriListFlavor)) {
				// to comply with RFC 2483
				String data = file.toURI() + "\r\n";
				return data;
			} else {
				throw new UnsupportedFlavorException(flavor);
			}
		}

		/*
		 * (non-Javadoc)
		 * @see java.awt.datatransfer.Transferable#getTransferDataFlavors()
		 */
		public DataFlavor[] getTransferDataFlavors() {
			return FLAVORS.clone();
		}

		/*
		 * (non-Javadoc)
		 * @see java.awt.datatransfer.Transferable#isDataFlavorSupported(java.awt.datatransfer.DataFlavor)
		 */
		public boolean isDataFlavorSupported(DataFlavor flavor) {
			for (int i = 0; i < FLAVORS.length; i++) {
				if (flavor.equals(FLAVORS)) {
					return true;
				}
			}
			return false;
		}

		/*
		 * (non-Javadoc)
		 * @see java.awt.dnd.DragGestureListener#dragGestureRecognized(java.awt.dnd.DragGestureEvent)
		 */
		public void dragGestureRecognized(DragGestureEvent dge) {
			dge.startDrag(DragSource.DefaultCopyDrop, this, this);
		}
	}

	/**
	 * Create an <code>ExportComponent</code> by specifying an export file
	 * and the image icon to use. You can pass null as icon (although I never tried...).
	 * 
	 * @param exportFile
	 * @param icon
	 */
	public ExportComponent(String exportFile, ImageIcon icon) {
		this.exportFile = exportFile;
		setIcon(icon);
		setSize(icon.getIconWidth(), icon.getIconHeight());
		setHorizontalAlignment(SwingConstants.CENTER);
		new DragAdapter(this);
	}
}
