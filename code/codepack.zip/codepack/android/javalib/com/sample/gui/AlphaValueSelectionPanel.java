/**
 * Copyright (C) 2003-2008 Vega Technologies SAS. All Rights Reserved.
 * All rights reserved
 *
 * Project: vegajlib
 */
package com.sample.gui;

import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.SwingConstants;
import javax.swing.colorchooser.AbstractColorChooserPanel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import net.jcip.annotations.NotThreadSafe;

/**
 * A selection panel to embed in a ColorChooser that allows to set the transparency value for a color.
 * 
 * @author Marco Dinacci <marco.dinacci@vegatechnologies.fr>
 */
@NotThreadSafe
public class AlphaValueSelectionPanel extends AbstractColorChooserPanel implements ChangeListener {

	private JSlider alphaSlider;
	private JLabel percentLabel;

	/* (non-Javadoc)
	 * @see javax.swing.colorchooser.AbstractColorChooserPanel#updateChooser()
	 */
	@Override
	public void updateChooser() {
		// nothing to do
	}
	
	/* (non-Javadoc)
	 * @see javax.swing.colorchooser.AbstractColorChooserPanel#getDisplayName()
	 */
	@Override
	public String getDisplayName() {
		return "Transparency selection";
	}

	/* (non-Javadoc)
	 * @see javax.swing.colorchooser.AbstractColorChooserPanel#getSmallDisplayIcon()
	 */
	@Override
	public Icon getSmallDisplayIcon() {
		// nothing to do
		return null;
	}

	/* (non-Javadoc)
	 * @see javax.swing.colorchooser.AbstractColorChooserPanel#getLargeDisplayIcon()
	 */
	@Override
	public Icon getLargeDisplayIcon() {
		// nothing to do
		return null;
	}
	
	/*
	 * (non-Javadoc)
	 * @see javax.swing.event.ChangeListener#stateChanged(javax.swing.event.ChangeEvent)
	 */
	public void stateChanged(ChangeEvent e) {
		correctColor();
		updateLabel();
	}
	
	@Override
	protected void buildChooser() {
		setLayout(new GridLayout(0, 1));
		alphaSlider = new JSlider(JSlider.HORIZONTAL, 0, 255, 128);
	    alphaSlider.addChangeListener(this);

		add(new JLabel("Choose alpha level for the selected color:", JLabel.CENTER));
	    JPanel jp = new JPanel();
	    jp.add(new JLabel("Full transparency"));
	    jp.add(alphaSlider);
	    jp.add(new JLabel("No transparency"));
	    add(jp);

	    JPanel jp2 = new JPanel();
	    percentLabel = new JLabel("50 %");
	    percentLabel.setHorizontalAlignment(SwingConstants.RIGHT);
	    jp2.add(percentLabel);
	    add(jp2);

	    correctColor();
	}
	
	/* (non-Javadoc)
	 * @see javax.swing.colorchooser.AbstractColorChooserPanel#buildChooser()
	 */
	private void correctColor() {
		Color current = getColorSelectionModel().getSelectedColor();
		Color corrected = new Color(current.getRed(), current.getGreen(), current.getBlue(), alphaSlider.getValue());
		getColorSelectionModel().setSelectedColor(corrected);
	}
	
	/*
	 * Update the label with the alpha value in percentage
	 */
	private void updateLabel() {
		percentLabel.setText(""
				+ (100 - (int) Math.round(alphaSlider.getValue() / 2.55)) + " %");
	}
}