/**
 * Copyright (C) 2003-2006 Vega Technologies SAS. All Rights Reserved.
 *
 * Project: vegajlib
 */
package com.sample.geom;

import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.GeneralPath;
import java.awt.geom.PathIterator;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

/**
 * A collection of custom 2D shapes
 * 
 * @author Marco Dinacci <marco.dinacci@vegatechnologies.fr>
 * @version $Id: CustomShape.java,v 1.1 2007/08/30 12:36:08 mdinacci Exp $
 */
public abstract class CustomShape implements Shape {

	/**  /\
	 *  /  \
	 *  |   | Honeycomb
	 *  \  /
	 *   \/
	 */
	public static class Honeycomb extends CustomShape {

		public Honeycomb(float width, float height) {
			setSize(width, height);
		}
		
		public Honeycomb() {
			setSize(4,4);
		}
		
		public void setSize(float width, float height) {
			this.width = width;
			this.height = height;
			
			GeneralPath path = new GeneralPath();
			
			path.moveTo(width/2,height/4);
			path.lineTo(width/2,-height/4);
			path.lineTo(0,-height/2);
			path.lineTo(-width/2,-height/4);
			path.lineTo(-width/2,height/4);
			path.lineTo(0,height/2);
			path.lineTo(width/2,height/4);
			path.closePath();

			shape = path;
			
		}
	}

	/* Width and height of the shape */
	protected float height, width;
	
	/* The custom shape */
	protected Shape shape;
	
	public Rectangle getBounds() {
		return shape.getBounds();
	}

	public Rectangle2D getBounds2D() {
		return shape.getBounds2D();
	}

	public boolean contains(double x, double y) {
		return shape.contains(x,y);
	}

	public boolean contains(Point2D p) {
		return shape.contains(p);
	}

	public boolean intersects(double x, double y, double w, double h) {
		return shape.intersects(x,y,w,h);
	}

	public boolean intersects(Rectangle2D r) {
		return shape.intersects(r);
	}

	public boolean contains(double x, double y, double w, double h) {
		return shape.contains(x,y,w,h);
	}

	public boolean contains(Rectangle2D r) {
		return shape.contains(r);
	}

	public PathIterator getPathIterator(AffineTransform at) {
		return shape.getPathIterator(at);
	}

	public PathIterator getPathIterator(AffineTransform at, double flatness) {
		return shape.getPathIterator(at,flatness);
	}
	
	public String toString() {
		return "w: " + width + " h: " + height;
	}
}
