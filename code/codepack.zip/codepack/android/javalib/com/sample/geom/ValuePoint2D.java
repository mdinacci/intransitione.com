/**
 * Copyright (C) 2003-2006 Vega Technologies SAS. All Rights Reserved.
 *
 * Project: vegajlib
 */
package com.sample.geom;

import java.awt.geom.Point2D;


/**
 * A <code>Point2D</code>with a value associated. 
 * Value can be any object.
 * 
 * @author Marco Dinacci <marco.dinacci@vegatechnologies.fr>
 * @version $Id: ValuePoint2D.java,v 1.1 2007/08/30 12:36:08 mdinacci Exp $
 * @see Point2D
 */
public abstract class ValuePoint2D extends Point2D {

	public static class Float <T> extends Point2D.Float {
		
		/* yes, it is public, like <code>x</code> and <code>y</code>. */ 
		public T value;
		
		/**
		 * Construct a new <code>ValuePoint2D</code>with the given 
		 * cartesian coordinates and value.
		 *  
		 * @param x The x coordinate of the point.
		 * @param y The y coordinate of the point.
		 * @param value The value attached to the point.
		 */
		public Float(float x, float y, T value) {
			super(x,y);
			this.value = value;
		}
		
		/**
		 * Get the value associated with this point.
		 * @return the value
		 */
		public T getValue() {
			return value;
		}
		
		/*
		 *  (non-Javadoc)
		 * @see java.lang.Object#toString()
		 */
		@Override
		public final String toString() {
			return "x: " + x + " y: " + y + " v: " + value;
		}
	}
	
    @NotThreadSafe
	public static class Double <T> extends Point2D.Double {
		
		/* yes, it is public, like <code>x</code> and <code>y</code>. */ 
		public T value;
		
		/**
		 * Construct a new <code>ValuePoint2D</code>with the given 
		 * cartesian coordinates and value.
		 *  
		 * @param x The x coordinate of the point.
		 * @param y The y coordinate of the point.
		 * @param value The value attached to the point.
		 */
		public Double(double x, double y, T value) {
			super(x,y);
			this.value = value;
		}
		
		/**
		 * Get the value associated with this point.
		 * @return the value
		 */
		public T getValue() {
			return value;
		}
		
		/*
		 *  (non-Javadoc)
		 * @see java.lang.Object#toString()
		 */
		@Override
		public final String toString() {
			return "x: " + x + " y: " + y + " v: " + value;
		}
	}
	
}
