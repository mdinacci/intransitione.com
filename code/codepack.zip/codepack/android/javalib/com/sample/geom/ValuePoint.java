/**
 * Copyright (C) 2003-2006 Vega Technologies SAS. All Rights Reserved.
 *
 * Project: vegajlib
 */
package com.sample.geom;

import java.awt.Point;


/**
 * A <code>Point</code> with a value associated. 
 * Value can be any object.
 * 
 * @author Marco Dinacci <marco.dinacci@vegatechnologies.fr>
 * @version $Id: ValuePoint.java,v 1.1 2007/08/30 12:36:08 mdinacci Exp $
 * @see Point
 */
public class ValuePoint <T> extends Point {

	/** Value field, public like <code>x</code> and <code>y</code> fields */
	public T value;

	public ValuePoint(int x, int y, T value) {
		super(x,y);
		this.value = value; 
	}
	
	/**
	 * Get the value associated with this point.
	 * @return the value
	 */
	public T getValue() {
		return value;
	}
	
	/*
	 *  (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "x: " + x + " y: " + y + " v: " + value;
	}
}
