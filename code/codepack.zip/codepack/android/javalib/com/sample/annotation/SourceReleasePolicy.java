/**
 * Copyright (C) 2006 Vega Technologies SAS. All Rights Reserved.
 *
 * Project: x-forge
 *
 */
package com.sample.annotation;

import java.lang.annotation .*;

/**
 * This annotation is used to specify whether a source file 
 * should be released to a client or not. A nifty tool can
 * then parse the code and get only what it is necessary to release.
 * 
 * It applies only to public classes inside a source unit.
 * If the policy is RELEASE than the source files must somehow be exported 
 * and delivered to the client.
 * 
 * XXX doesn't support multiple clients ! (but you can use it multiple times)
 * 
 * @author Marco Dinacci <marco.dinacci@vegatechnologies.fr>
 * @version $Id: SourceReleasePolicy.java,v 1.1 2007/08/30 13:33:41 mdinacci Exp $
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface SourceReleasePolicy {
	String clientId();
	
	// available choices: NOT_RELEASE, RELEASE
	String policy() default "NOT_RELEASE";
}
