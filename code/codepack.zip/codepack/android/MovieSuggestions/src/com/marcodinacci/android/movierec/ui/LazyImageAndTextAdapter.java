package com.marcodinacci.android.movierec.ui;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.marcodinacci.android.commons.ui.ImageAndTextAdapter;
import com.marcodinacci.android.movierec.MovieUtils;
import com.marcodinacci.social.rottentomatoes.data.Movie;
import com.marcodinacci.social.rottentomatoes.data.MovieList;

/**
 * A generic Adapter for ListView widgets that provide an Icon and a String. The
 * icon is loaded from the internet.
 */
public class LazyImageAndTextAdapter extends ImageAndTextAdapter {

	private static final String TAG = LazyImageAndTextAdapter.class.getName();
	
	private static final String EMPTY_STRING = "".intern();
	
	private MovieList mMovieList;

	public LazyImageAndTextAdapter(Context ctx, int viewResourceId,
			MovieList movieList) {
		super(ctx, viewResourceId, new String[]{});

		mMovieList = movieList;
		
		mInflater = (LayoutInflater) ctx
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

		mViewResourceId = viewResourceId;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		Movie movie;
		
		if(position < mMovieList.getTotal())
			movie = mMovieList.get(position);
		else {
			Log.e(TAG, "Position greater than movie list size");
			return convertView;
		}
		
		if (convertView == null) {
			convertView = mInflater.inflate(mViewResourceId, null);
		}
		
		return MovieUtils.fillUI(convertView, movie);
	}
	
	@Override
	public int getCount() {
		return mMovieList.getTotal();
	}

	@Override
	public String getItem(int position) {
		return EMPTY_STRING;
	}
}
