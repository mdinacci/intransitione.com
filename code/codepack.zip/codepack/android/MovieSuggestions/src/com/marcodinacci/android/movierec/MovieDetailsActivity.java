package com.marcodinacci.android.movierec;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.ListView;
import android.widget.Toast;

import com.marcodinacci.commons.network.SimpleConnector;
import com.marcodinacci.social.rottentomatoes.RottenTomatoesConnector;
import com.marcodinacci.social.rottentomatoes.data.Movie;
import com.marcodinacci.social.rottentomatoes.data.impl.RottenTomatoesMovieLinks;
import com.marcodinacci.social.rottentomatoes.data.impl.RottenTomatoesMovieReviewList;

public class MovieDetailsActivity extends Activity {

	private static final String TRAILER_ENDPOINT = "trailerapi.com";
	private static final String TAG = G.TAG(MovieDetailsActivity.class);

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// set orientation to portrait because after returning from the
		// youtube activity orientation may be stuck to landscape
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
		requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
		
		setContentView(R.layout.movie_details);

		getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.window_title);
		
		findViewById(R.id.youtube_icon).setVisibility(View.VISIBLE);
	}

	@Override
	protected void onStop() {
		super.onStop();

		findViewById(R.id.youtube_icon).setVisibility(View.INVISIBLE);
	};

	@Override
	protected void onResume() {
		super.onResume();

		final Movie movie = (Movie) getIntent().getExtras().getParcelable(
				"movie");

		String title = movie.getAttribute(Movie.KEY_ENGLISH_TITLE);
		Log.i(TAG, "Showing movie details for: " + title);

		MovieUtils.fillUI(getWindow().getDecorView(), movie);

		// get youtube link
		final CharSequence cs = getTrailerLink(movie
				.getAttribute(Movie.KEY_ENGLISH_TITLE));

		Log.d(TAG, "Youtube URL is: " + cs.toString());

		View v = findViewById(R.id.youtube_icon);

		// TODO check URL, if valid show icon and setOnClickListener
		v.setVisibility(View.VISIBLE);

		v.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				String s = getString(R.string.launching_trailer);
				Toast.makeText(MovieDetailsActivity.this, s,
						Toast.LENGTH_SHORT).show();
				// With this line the Youtube application, if installed, will
				// launch immediately.
				// Without it you will be prompted with a list of the
				// application to choose.
				Uri uri = Uri.parse(cs.toString());
				Log.i(TAG, "Obtained Youtube url: " + uri.toString());
				uri = Uri.parse("vnd.youtube:" + uri.getQueryParameter("v"));

				Intent intent = new Intent(Intent.ACTION_VIEW, uri);
				startActivity(intent);
			}
		});

		RottenTomatoesMovieLinks links = (RottenTomatoesMovieLinks) movie
				.getMovieLinks();

		getReviews(links.getReviewsLink());
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		boolean b = super.onCreateOptionsMenu(menu);

		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.options_menu, menu);

		return b;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.aboutItem:
			MRApplication.getAboutDialog(this).show();
			break;

		default:
			break;
		}

		return super.onOptionsItemSelected(item);
	}

	private void getReviews(String reviewsLink) {
		Log.d(TAG, "Starting reviews task");

		new AsyncTask<String, Void, Void>() {

			RottenTomatoesMovieReviewList reviews;
			private ProgressDialog mProgressDialog;

			@Override
			protected Void doInBackground(String... params) {
				Log.d(TAG, "Review task running");

				MRApplication app = (MRApplication) getApplication();
				RottenTomatoesConnector conn = app.getConnector();
				reviews = conn.getReviews(params[0]);

				return null;
			}

			@Override
			protected void onPreExecute() {
				String msg = getString(R.string.loading_movie_details);
				mProgressDialog = ProgressDialog.show(
						MovieDetailsActivity.this, null, msg, true);
			}

			@Override
			protected void onPostExecute(Void result) {
				super.onPostExecute(result);

				mProgressDialog.dismiss();

				showReviews(reviews);
			}
		}.execute(reviewsLink);
	}

	protected void showReviews(RottenTomatoesMovieReviewList reviews) {
		if (reviews == null || reviews.getTotal() == 0) {
			Log.d(TAG, "No reviews found");

			return;
		}

		Log.i(TAG, reviews.getTotal() + " reviews fouund");

		final MovieReviewsAdapter la = new MovieReviewsAdapter(this,
				R.layout.movie_review_item, reviews);
		ListView lv = (ListView) findViewById(R.id.movies_reviews);
		lv.setAdapter(la);
	}

	private CharSequence getTrailerLink(String attribute) {
		Log.d(TAG, "Getting youtube trailer");

		SimpleConnector connector = new SimpleConnector(TRAILER_ENDPOINT);
		return connector.get("/turl/" + Uri.encode(attribute));
	}
}
