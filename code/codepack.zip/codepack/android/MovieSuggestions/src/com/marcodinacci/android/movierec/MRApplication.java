package com.marcodinacci.android.movierec;

import android.app.AlertDialog;
import android.app.Application;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.marcodinacci.android.movierec.os.MRExceptionHandler;
import com.marcodinacci.social.rottentomatoes.RottenTomatoesConnector;

public class MRApplication extends Application {

	private static final String API_KEY = "";
	private static Dialog mAboutDialog;
	
	private final RottenTomatoesConnector mConnector;

	public MRApplication() {
		mConnector = new RottenTomatoesConnector(API_KEY, null);
		Thread.setDefaultUncaughtExceptionHandler(new MRExceptionHandler());
	}
	
	public RottenTomatoesConnector getConnector() {
		return mConnector;
	}
	
	public static Dialog getAboutDialog(final Context ctx) {
		if(mAboutDialog != null)
			return mAboutDialog;
		
		AlertDialog.Builder builder;

		LayoutInflater inflater = (LayoutInflater) ctx.getSystemService(LAYOUT_INFLATER_SERVICE);
		View layout = inflater.inflate(R.layout.about_dialog, null);

		Button btn = (Button) layout.findViewById(R.id.emailBtn);
		btn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String email = ctx.getString(R.string.about_email);
				String subject = ctx.getString(R.string.email_subject);
					
				Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
				emailIntent.setType("text/plain");
				
				emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, 
						new String[]{email});
				
				emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, 
						subject);
				
				ctx.startActivity(Intent.createChooser(emailIntent,
						"Send mail..."));
			}
		});
		
		builder = new AlertDialog.Builder(ctx);
		builder.setView(layout);
		
		mAboutDialog = builder.create();
		
		return mAboutDialog;
	}
}
