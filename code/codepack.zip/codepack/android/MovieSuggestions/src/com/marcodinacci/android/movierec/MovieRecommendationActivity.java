package com.marcodinacci.android.movierec;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.marcodinacci.android.movierec.ui.LazyImageAndTextAdapter;
import com.marcodinacci.social.rottentomatoes.RottenTomatoesConnector;
import com.marcodinacci.social.rottentomatoes.data.Movie;
import com.marcodinacci.social.rottentomatoes.data.impl.RottenTomatoesMovieLinks;
import com.marcodinacci.social.rottentomatoes.data.impl.RottenTomatoesMovieList;

public class MovieRecommendationActivity extends Activity {

	private static final String TAG = G.TAG(MovieRecommendationActivity.class);

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);

		setContentView(R.layout.movies_recommended);
		
		getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.window_title);
	}

	@Override
	protected void onResume() {
		super.onResume();

		final Movie movie = (Movie) getIntent().getExtras().getParcelable(
				"movie");
		String title = movie.getAttribute(Movie.KEY_ENGLISH_TITLE);

		Log.i(TAG, "Showing recommended movies for: " + title);

		TextView tv = (TextView) findViewById(R.id.movie_title);
		tv.setText(title);

		View v = getWindow().getDecorView();
		
		MovieUtils.fillUI(v, movie);
		
		View container = v.findViewById(R.id.movieContainer);
		container.setOnClickListener(
				new OnClickListener() {

					@Override
					public void onClick(View v) {
						Intent intent = new Intent(
								MovieRecommendationActivity.this,
								MovieDetailsActivity.class);
						Bundle bundle = new Bundle();
						bundle.putParcelable("movie", movie);
						intent.putExtras(bundle);

						startActivity(intent);
					}
				});

		// now get similar movies
		RottenTomatoesMovieLinks links = (RottenTomatoesMovieLinks) movie
				.getMovieLinks();
		getSimilarMovies(links.getSimilarMoviesLink());
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		boolean b = super.onCreateOptionsMenu(menu);

		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.options_menu, menu);

		return b;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.aboutItem:
			MRApplication.getAboutDialog(this).show();
			break;

		default:
			break;
		}

		return super.onOptionsItemSelected(item);
	}

	public void getSimilarMovies(String uri) {

		new AsyncTask<String, Void, Void>() {

			RottenTomatoesMovieList mMovieList;
			private ProgressDialog mProgressDialog;

			@Override
			protected Void doInBackground(String... params) {
				// search the movie by title
				MRApplication app = (MRApplication) getApplication();
				RottenTomatoesConnector conn = app.getConnector();

				mMovieList = conn.getRelatedMovies(params[0]);

				return null;
			}

			@Override
			protected void onPreExecute() {
				String msg = getString(R.string.looking_for_related_movies);
				mProgressDialog = ProgressDialog.show(
						MovieRecommendationActivity.this, null, msg, true);
			}

			@Override
			protected void onPostExecute(Void result) {
				super.onPostExecute(result);

				mProgressDialog.dismiss();

				showSearchResults(mMovieList);
			}
		}.execute(uri);

	}

	protected void showSearchResults(final RottenTomatoesMovieList movieList) {
		if (movieList == null) {
			Log.e(TAG, "Movie list is null, no results found");
			return;
		}

		Log.i(TAG, movieList.getTotal() + " movies found.");

		if (movieList.getTotal() == 0) {

			Log.i(TAG, "No movies found, going back to previous activity");

			Context ctx = MovieRecommendationActivity.this;
			Toast.makeText(ctx, getString(R.string.no_related_movies_found),
					Toast.LENGTH_SHORT).show();

			final Handler handler = new Handler();

			Runnable r = new Runnable() {

				@Override
				public void run() {
					onBackPressed();
				}
			};

			handler.postDelayed(r, 2000);

			return;
		}

		ListAdapter la = new LazyImageAndTextAdapter(this,
				R.layout.movie_list_item, movieList);
		ListView lv = (ListView) findViewById(R.id.movies_recommended);
		lv.setAdapter(la);
		lv.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {

				Intent intent = new Intent(MovieRecommendationActivity.this,
						MovieDetailsActivity.class);
				Bundle bundle = new Bundle();
				bundle.putParcelable("movie", movieList.get(position));
				intent.putExtras(bundle);

				startActivity(intent);
			}
		});
	}
}
