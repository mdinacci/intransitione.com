package com.marcodinacci.android.movierec;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.marcodinacci.social.rottentomatoes.data.MovieReview;
import com.marcodinacci.social.rottentomatoes.data.impl.RottenTomatoesMovieReviewList;

public class MovieReviewsAdapter extends BaseAdapter {

	private static final String TAG = G.TAG(MovieReviewsAdapter.class);
	private int mLayout;
	private RottenTomatoesMovieReviewList mReviews;
	private LayoutInflater mInflater;

	public MovieReviewsAdapter(Context ctx, int layout,
			RottenTomatoesMovieReviewList reviews) {

		mLayout = layout;
		mReviews = reviews;

		mInflater = (LayoutInflater) ctx
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	}

	@Override
	public int getCount() {
		return mReviews.getTotal();
	}

	@Override
	public Object getItem(int position) {
		return mReviews.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		if (convertView == null) {
			convertView = mInflater.inflate(mLayout, null);
		}

		MovieReview review;
		if (position < mReviews.getTotal())
			review = mReviews.get(position);
		else {
			Log.e(TAG, "Position greater than movie list size");
			return convertView;
		}
		
		if(review == null) {
			Log.w(TAG, "Review was null, not showing it");
			return convertView;
		}

		TextView publication = (TextView) convertView
				.findViewById(R.id.publicationText);
		
		if(publication != null)
			publication.setText(review.getPublication());
		
		TextView rating = (TextView) convertView
		.findViewById(R.id.reviewRatingText);

		if(rating != null)
			rating.setText(review.getRating());
		
		TextView quote = (TextView) convertView
		.findViewById(R.id.reviewText);

		if(quote != null) {
			String msg = review.getQuote();
			// review is too short, display a not available message instead.
			if(msg.length() < 3)
				msg = convertView.getContext().getString(R.string.not_available);
			quote.setText(msg);
		}

		return convertView;
	}
}
