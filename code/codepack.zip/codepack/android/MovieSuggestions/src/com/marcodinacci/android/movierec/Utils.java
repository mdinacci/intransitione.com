package com.marcodinacci.android.movierec;

import android.graphics.Color;

public class Utils {

	public static int colorForScore(int score) {
		int c;
		
		if(score >= 70)
			c = Color.GREEN;
		else if(score >= 40)
			c = Color.YELLOW;
		else
			c = Color.RED;
		
		return c;
	}
}
