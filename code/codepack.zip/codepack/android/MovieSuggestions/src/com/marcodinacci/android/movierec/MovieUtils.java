package com.marcodinacci.android.movierec;

import android.net.Uri;
import android.text.Html;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.marcodinacci.android.commons.ui.ImageDownloader;
import com.marcodinacci.social.rottentomatoes.data.Movie;

public class MovieUtils {

	private static final String NOT_AVAILABLE = "";
	private static final ImageDownloader imageDownloader = new ImageDownloader(
			ImageDownloader.Mode.CORRECT);

	private static final int MAX_SYNOPSYS_LENGTH = 150;
	
	private static final String TAG = G.TAG(MovieUtils.class);

	private static String getShortSynopsis(Movie movie) {
		String syn = NOT_AVAILABLE;

		syn = movie.getAttribute(Movie.KEY_SYNOPSIS);
		if (syn.length() <= 3) {
			syn = movie.getAttribute(Movie.KEY_CRITICS_CONSENSUS);
			if (syn == null || syn.length() <= 3)
				syn = NOT_AVAILABLE;
		}

		if (syn.length() > MAX_SYNOPSYS_LENGTH)
			syn = syn.substring(0, MAX_SYNOPSYS_LENGTH) + "...";

		return syn;
	}

	public static View fillUI(View view, Movie movie) {
		if (movie == null) {
			Log.e(TAG, "Movie WAS NULL");
			return view;
		}

		Log.d(TAG, "Filling the UI with movie attributes");
		
		// fill icon
		Uri uri = Uri.parse(movie.getMoviePoster().getAttribute(
				Movie.KEY_POSTER_PROFILE));
		ImageView iv = (ImageView) view.findViewById(R.id.movie_icon);
		iv.setTag(uri.toString());

		imageDownloader.download(uri.toString(), (ImageView) iv);

		// fill title, year and rating
		String movieTitle = movie.getAttribute(Movie.KEY_ENGLISH_TITLE);
		movieTitle = TextUtils.htmlEncode(movieTitle);

		String score = movie.getAttribute(Movie.KEY_AVERAGE_SCORE);
		String text = view.getResources().getString(R.string.movie_header);
		String year = movie.getAttribute(Movie.KEY_RELEASE_YEAR);
		text = String.format(text, movieTitle, year);

		int scoreInt = Integer.parseInt(score);
		SpannableString ss = new SpannableString(" " + score + "%");
		ss.setSpan(new ForegroundColorSpan(Utils.colorForScore(scoreInt)), 0,
				ss.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
		SpannableStringBuilder builder = new SpannableStringBuilder(
				Html.fromHtml(text)); 
		builder.append(ss.subSequence(0, ss.length()));

		TextView titleView = (TextView) view.findViewById(R.id.movie_title);
		titleView.setText(builder, TextView.BufferType.SPANNABLE);

		// fill synopsis
		TextView synView = (TextView) view.findViewById(R.id.movie_synopsis);
		synView.setText(MovieUtils.getShortSynopsis(movie));

		// fill cast if available
		TextView castView = (TextView) view.findViewById(R.id.castText);
		if (castView != null) {
			String s = movie.getMovieCast().toString();
			castView.setText(s.substring(0, s.length() - 1));
		}

		return view;
	}
}
