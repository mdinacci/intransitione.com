package com.marcodinacci.android.movierec;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;

import com.marcodinacci.android.commons.Eula;
import com.marcodinacci.android.movierec.ui.LazyImageAndTextAdapter;
import com.marcodinacci.social.rottentomatoes.RottenTomatoesConnector;
import com.marcodinacci.social.rottentomatoes.data.impl.RottenTomatoesMovieList;

public class MainActivity extends Activity implements Eula.OnEulaAgreedTo {

	/*
	 * To start the search for a movie as soon as the user finishes writing the
	 * title.
	 */
	final class MREditorActionListener implements OnEditorActionListener {

		@Override
		public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
			if (v.getText() != null && v.getText().length() > 2) {
				searchMovie(v.getText().toString());
			}
			return false;
		}
	}

	private static final String TAG = G.TAG(MainActivity.class);

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
		
		if(Eula.show(this, false)) onEulaAgreedTo();
	}
	
	@Override
	public void onEulaAgreedTo() {
		setContentView(R.layout.main);

		getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.window_title);
		
		// erase the initial text in the EditText when the user click
		final EditText et = (EditText) findViewById(R.id.movieEditText);

		et.setOnEditorActionListener(new MREditorActionListener());
		et.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				et.setText("");
			}
		});
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		boolean b = super.onCreateOptionsMenu(menu);
		
		MenuInflater inflater = getMenuInflater();
	    inflater.inflate(R.menu.options_menu, menu);
		
		return b;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.aboutItem:
			MRApplication.getAboutDialog(this).show();
			
			break;

		default:
			break;
		}
		
		return super.onOptionsItemSelected(item);
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
		
		// simply overriding this method won't trigger a new onCreate for
		// orientation and keyboard hidden changes (see also AndroidManifest)
	}
	
	public void searchMovie(String text) {

		Log.d(TAG, "Starting search movie task");

		new AsyncTask<String, Void, Void>() {

			RottenTomatoesMovieList mMovieList;
			private ProgressDialog mProgressDialog;

			@Override
			protected Void doInBackground(String... params) {
				Log.d(TAG, "Search movie task running");

				// search the movie by title
				MRApplication app = (MRApplication) getApplication();
				RottenTomatoesConnector conn = app.getConnector();
				mMovieList = conn.searchMovie(params[0]);

				return null;
			}

			protected void onPreExecute() {
				String msg = getString(R.string.searching_movie);
				mProgressDialog = ProgressDialog.show(MainActivity.this, null,
						msg, true);
			};

			@Override
			protected void onPostExecute(Void result) {
				Log.d(TAG, "Search task terminated");

				super.onPostExecute(result);

				mProgressDialog.dismiss();

				showSearchResults(mMovieList);
			}
		}.execute(text);

	}

	/*
	 * Show the results of a movie search.
	 */
	private void showSearchResults(final RottenTomatoesMovieList movieList) {
		Log.d(TAG, "Showing search results");

		if (movieList == null || movieList.getTotal() == 0) {

			Log.d(TAG, "Search returned 0 movies or movie list was null");

			String msg = getString(R.string.no_movies_found);
			Toast.makeText(this, msg, Toast.LENGTH_LONG).show();

			return;
		}

		Log.d(TAG, "Search returned " + movieList.getTotal() + " results");

		final LazyImageAndTextAdapter la = new LazyImageAndTextAdapter(this,
				R.layout.movie_list_item, movieList);
		ListView lv = (ListView) findViewById(R.id.movieList);
		lv.setAdapter(la);
		lv.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {

				Log.d(TAG, "User clicked on the recommendation positioned at: "
						+ position);

				Intent intent = new Intent(MainActivity.this,
						MovieRecommendationActivity.class);

				Bundle bundle = new Bundle();
				bundle.putParcelable("movie",
						(Parcelable) movieList.get(position));
				intent.putExtras(bundle);

				startActivity(intent);
			}
		});
	}
}