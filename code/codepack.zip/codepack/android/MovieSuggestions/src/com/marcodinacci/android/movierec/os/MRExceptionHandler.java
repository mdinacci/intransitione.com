package com.marcodinacci.android.movierec.os;

import android.util.Log;

import com.marcodinacci.android.movierec.G;

public final class MRExceptionHandler implements
		Thread.UncaughtExceptionHandler {

	private static final String TAG = G.TAG(MRExceptionHandler.class);

	
	@Override
	public void uncaughtException(Thread thread, Throwable ex) {
		Log.e(TAG, "Uncaught exception: " + ex.getMessage());
	}
}
