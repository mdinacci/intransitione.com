package com.marcodinacci.android.movierec;

/**
 * G = Global
 */
public class G {
	
	private static final String PREFIX = "[MR] ".intern();
	private static final int MAXIMUM_LENGTH = 22;
	
	public static final String TAG(@SuppressWarnings("rawtypes") Class c) {
		String tag = PREFIX + c.getCanonicalName();
		StringBuffer tagsb = new StringBuffer(); 
		
		int length = tag.length();
		if(length > MAXIMUM_LENGTH) {
			// the prefix must always be present
			int prefixLength = PREFIX.length();
			tagsb.append(tag.substring(0, prefixLength));
			
			int startOffset = length - (MAXIMUM_LENGTH - prefixLength);
			tagsb.append(tag.substring(startOffset, length));
		}
		
		return tagsb.toString();
	}
}