This folder contains some "recipes" I've written for the Android Cookbook
book edited by O'Reilly. Some folders also contains some Java source code.