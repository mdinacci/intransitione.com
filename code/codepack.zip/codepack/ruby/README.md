This is a project I've written to learn Ruby.
It scrapes the content of careers.stackoverflow.com to extract the tags used
in the job descriptions and save them as json. These json files are then
fed to the Google Visualization API to make some pretty charts.
You can see some in this [blog post](http://intransitione.com/blog/look-it-job-market/)
The code in js/charts.js is used to create the charts.

It requires Nokogiri to run:

gem install nokokiri

After that, run simply with:

$ ruby runme.rb
