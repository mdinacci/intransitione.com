This is a simple project I've written to familiarise myself with Golang.
Please see the README.md file in the project directory.
