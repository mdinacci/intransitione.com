/*
 * SMAISS
 *
 * Copyright (c) 2013 Infinity Realm. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Infinity Realm. ("Confidential Information").  You shall
 * not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Infinity Realm.
 *
 * INFINITY REALM MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. INFINITY REALM SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */

/* global console:false */
/* global base:false */


var SMAISS = (function(){
    "use strict";

    // PRIVATE

    /* The callback called when a response from the backend is received. */
    var uploadCallback;

    /* The client api key */
    var smaiss_api_key;

    /* Allows selection of multiple photos from a service */
    var SELECTION_MODE_MULTIPLE = "1";

    /* Allows selection of only one photo from a service  */
    var SELECTION_MODE_SINGLE = "0";

    /* The dialog containing the iframe */
    var theDialog;

    // OPTIONS

    /* Language settings */
    var smOptions = {'lang' : 'auto'};

    /**/

    /* Call the given function when the given element is clicked */
    function addClickEvent(element, funct){
        if (element.addEventListener) {
            element.addEventListener("click", funct, false);
        } else if (element.attachEvent) {
            element.attachEvent("onclick", funct);
        }
    }

    function getViewport() {
        var e = window, a = 'inner';
        if ( !( 'innerWidth' in window ) ) {
            a = 'client';
            e = document.documentElement || document.body;
        }
        return { width : e[ a+'Width' ] , height : e[ a+'Height' ] };
    }

    function isBrowserSupported() {
        var is_chrome = navigator.userAgent.indexOf('Chrome') > -1;
        var is_safari = navigator.userAgent.indexOf("Safari") > -1;
        if ((is_chrome)&&(is_safari)) {is_safari=false;}
        var is_Opera = navigator.userAgent.indexOf("Presto") > -1;

        // Supports everything except any IE less than 8
        // See http://tanalin.com/en/articles/ie-version-js/
        var isIE7OrLess = ! (document.all && (!document.documentMode || (document.documentMode && document.documentMode < 8)));
        var isSafari512OrLess = is_safari;

        return isIE7OrLess;
    }

    /*
    * Display the services dialog
    */
    function displayDialog(selectionMode, title) {
        if (! smaiss_api_key) {
            console.log("Invalid API KEY.");
            return;
        }

        if (selectionMode !== SELECTION_MODE_SINGLE &&
            selectionMode !== SELECTION_MODE_MULTIPLE) {
            selectionMode = 0;
        }

        var params = '?ak=' + smaiss_api_key + '&lang=' + smOptions.lang + '&sm=' + selectionMode;

        var page = 'http://api.smaiss.com:8080/v0/services' + params;
        if (! isBrowserSupported()) {
            page = 'http://api.smaiss.com:8080/v0/unsupported' + params;
        }

        var windowSize = getViewport();
        theDialog = $('<div id="smaiss-dialog-container"></div>')
            .html('<iframe id="smaiss-dialog" src="' + page + '"width=100%, height=100%"></iframe>')
            .dialog({
                autoOpen: false,
                modal: true,
                draggable: true,
                height: windowSize.height * 4/5,
                width: windowSize.width * 4/5,
                title: title,
                closeOnEscape: false
            });

        theDialog.dialog('open');
    }

    function forwardBackendResponse(response) {
        if (typeof response.error !== 'undefined') {
            console.log("TODO ERROR");
        } else {
            uploadCallback(response.data);
            hideDialog();
        }
    }

    function chooseSingle() {
        displayDialog(SELECTION_MODE_SINGLE, "");
    }

    function chooseMultiple() {
        displayDialog(SELECTION_MODE_MULTIPLE, "");
    }

    function hideDialog() {
        theDialog.dialog('close');
    }

    function parseOptions(options) {
        if (options.lang) {
            smOptions.lang = options.lang;
        }
    }

    return {
        /**
         * Init the module.
         *
         * @param api_key
         * @param callback
         */
        init: function (api_key, options, callback) {
            uploadCallback = callback;
            smaiss_api_key = api_key;

            parseOptions(options);

            // Register parseBackendResponse as a listener for the window.postMessage events
            // sent by the code in the iFrame.
            if (window.addEventListener) {
                window.addEventListener("message", forwardBackendResponse, false);
            } else {
                window.attachEvent("onmessage", forwardBackendResponse);
            }

            // Look for elements with specific classes in order to attach the functions to
            // launch the dialogs
            var chooseMultipleElements = document.getElementsByClassName("smaiss-multiple");
            var chooseSingleElements = document.getElementsByClassName("smaiss-single");

            if (chooseMultipleElements.length === 0 && chooseSingleElements.length === 0) {
                console.log("No elements found in the document having the required classes (smaiss-multiple or smaiss-single)");
                return;
            }

            // Bind all buttons with the class 'smaiss-multiple' to the chooseMultiple function.
            for (var i = 0; i < chooseMultipleElements.length; i++) {
                addClickEvent(chooseMultipleElements[i], chooseMultiple);
            }

            for (i = 0; i < chooseSingleElements.length; i++) {
                addClickEvent(chooseSingleElements[i], chooseSingle);
            }
        }
    };
})();
