/*
 * SMAISS
 *
 * Copyright (c) 2013 Marco Dinacci. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Infinity Realm. ("Confidential Information").  You shall
 * not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Infinity Realm.
 *
 * INFINITY REALM MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. INFINITY REALM SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */

/* global $:false */
/* global console:false */
/* global Mustache:false */

/*
* This is the "private" API used by all the importers.
* Clients do not ever use this code, they are only exposed the functionalities in smaiss.js.
* */

// TODO It won't work (probably) in IE 10, replace with jQuery
Element.prototype.flipClass = function(clazz) {
    "use strict";

    var offset = this.className.indexOf(clazz);
    if (offset === -1) {
        this.className += " " + clazz;
    } else {
        this.className = this.className.replace(new RegExp("(?:^|\\s+)" + clazz + "(?:\\s+|$)", "g"), " ");
    }
};

var cache = {};
var cacheEnabled = true;

var SMAISSP = (function() {
    "use strict";

    var service;

    function addClickEvent(element, funct){
        if (element.addEventListener) {
            element.addEventListener("click", funct, false);
        } else if (element.attachEvent) {
            element.attachEvent("onclick", funct);
        }
    }

    function ajaxPost(url, data, callback) {
        // TODO add animation
        $.ajax({
                url: url,
                type: 'POST',
                dataType: 'JSON',
                data: data,
                beforeSend: function(jqXHR) {
                },
                done: function(response) {
                    callback(response);
                },
                fail: function(response) {
                    console.log('Failed to upload photos');
                },
                always: function(dataOrjqXHR) {
                }
            });
    }

    function switchService(serviceName) {
        if (!serviceName || service === serviceName) {
            return;
        }

        service = serviceName;

        if (cacheEnabled && service in cache) {
            console.log('Loading service ' + service + ' from cache.');
            $('#service-content').html(cache[service]);
        } else {
            console.log('Loading service ' + service + ' from server.');
            var url = '//api.smaiss.com:8080/v0/services/' + serviceName;
            var serviceContent = $('#service-content');
            serviceContent.empty();
            serviceContent.load(url, function(responseText, status, xhr) {
                if (status === 'error') {
                    console.log('Error loading service ' + serviceName);
                } else {
                    if (cacheEnabled) {
                        cache[service] = responseText;
                    }
                }
            });
        }

    }

    return {
        selectedPhotos: [],

        /**
         * Switch service when a service link is clicked.
         * The service name is read from the "service-name" attribute.
         */
        init: function() {
            $('.service-link').each(function(index, element) {
                $(this).on('click', function() {
                    try {
                        var serviceName = $(this).attr('service-name');
                        switchService(serviceName);
                        console.log("Service switched to " + serviceName);
                    } catch(error) {
                        console.trace();
                    }
                });
            });
        },

        /**
         * Upload the photos to the backend.
         * @param jsonPhotos A JSON description of the photos selected by the user.
         */
        uploadPhotos: function(jsonPhotos) {
            var jsonString = JSON.stringify(jsonPhotos);
            var url = "http://api.smaiss.com:8080/v0/services/" + service + "/upload";

            ajaxPost(url, jsonString, function(response) {
                var photos = JSON.parse(response);
                window.top.postMessage(photos, '*');
            });
        },

        /**
         * Call the given function when an element matched by the given selector is clicked.
         *
         * @param selector The selector to obtain the elements to which add the event listener.
         * @param func The function to call.
         */
        registerElementsForClick: function(selector, func) {
            var elements = document.querySelectorAll(selector);
            for (var i = 0; i < elements.length; i++) {
                var element = elements[i];
                addClickEvent(element, func);
            }
        },

        /**
         * Remove all children from the given element.
         *
         * @param parent The element from which all children will be removed.
         */
        removeChildren: function (parent) {
            while (parent.firstChild) {
                // Not assigning the removed child should guarantee the memory
                // will be released when the garbage collector kicks in.
                parent.removeChild(parent.firstChild);
            }
        },

        /**
         * Render a Mustache template.
         *
         * @param templateName The name of the template
         * @param view The parameters for the template
         * @param target The element that will contain the template
         */
        renderTemplate: function (templateName, view, target) {
            var template = document.getElementById(templateName).innerHTML;
            var output = Mustache.render(template, view);
            target.innerHTML += output;
        },

        /**
         * Get a query parameter by name
         *
         * @param name
         * @returns {string}
         */
        getParameterByName: function (name) {
            name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
            var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
                results = regex.exec(location.search);
            return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
        }
    };
})();
