/* global console:false */
/* global Mustache:false */
/* global SMAISSP:false */
/* global $:false */
/* global FB:false */
/* global cache:false */

var SMAISS_FB = (function() {
    "use strict";

    function flipPhoto(photo) {
        photo.flipClass("selected");
        var overlay = photo.nextSibling;
        overlay.flipClass("invisible");
        overlay.flipClass("visible");
    }

    /* Render all album covers in one go. */
    function renderAlbumsCover(albumsInfo) {
        var albumsNavigation = document.getElementById("fb-albums-navigation");
        for (var i = 0, additionalHeight = 0; i < albumsInfo.albums.length; i++) {
            additionalHeight += parseInt(albumsInfo.albums[i].height, 10);
        }

        SMAISSP.renderTemplate("albums-template", albumsInfo, albumsNavigation);
    }

    /* Render one photo */
    function renderPhoto(imageInfo, target) {
        SMAISSP.renderTemplate("album-template", imageInfo, target);
    }

    function fetchAlbum(albumID, selectionMode) {
        // Remove all existing images from a previous album.
        var albumPhotos = document.getElementById("fb-album-photos");
        SMAISSP.removeChildren(albumPhotos);

        console.log("Fetching photos from album: " + albumID);
        var path = '/' + albumID + '/photos';
        FB.api(path, function(response) {
            if (!response) {
                console.log("Invalid response");
                return;
            }

            var imageObjects = response.data;

            // Hold information about the image
            var photoInfo = {};

            // Where the image will be rendered
            var target = document.getElementById("fb-album-photos");
            for (var i = 0; i < imageObjects.length; i++) {
                var imageObject = imageObjects[i];
                var images = imageObject.images;
                photoInfo.name = imageObject.name;
                photoInfo.source = imageObject.source;
                // Images are ordered by quality so the first is the best one.
                photoInfo.highQuality = images[0].source;
                // Initialize the thumbnail to the source, but search for a smaller
                // image more suitable as a thumbnail.
                photoInfo.thumbnail = imageObject.source;
                // Find a suitable image to use as a thumbnail
                for (var j = 0; j < images.length; j++) {
                    if (images[j].width === 180) {
                        photoInfo.thumbnail = images[j].source;
                        break;
                    }
                }

                renderPhoto(photoInfo, target);
            }

            SMAISSP.registerElementsForClick(".photo-thumbnail", function(evt) {
                if (!evt){
                    evt = window.event;
                }

                var clickedPhoto = evt.toElement;
                var selectedPhoto = SMAISSP.selectedPhotos[0];

                if (selectionMode === "1") {
                    // Multiple selection

                    flipPhoto(clickedPhoto);
                    SMAISSP.selectedPhotos.push(clickedPhoto);
                } else {
                    // Single selection

                    // In any case, disable the currently selected photo if we have one.
                    if (SMAISSP.selectedPhotos.length > 0) {
                        flipPhoto(selectedPhoto);
                        // If the clicked photo is equal to the selected photo, we're done.
                        // Otherwise, flip the clicked photo to select it.
                        if (clickedPhoto.getAttribute("src") !== selectedPhoto.getAttribute("src")) {
                            flipPhoto(clickedPhoto);
                            // Remove old selectedPhoto...
                            SMAISSP.selectedPhotos.pop();
                            // and add the new one.
                            SMAISSP.selectedPhotos.push(clickedPhoto);
                        } else {
                            // They were the same, remove the photo from the array.
                            SMAISSP.selectedPhotos.pop();
                        }
                    } else {
                        // This is the first time the user select a photo, just select it
                        // and add it to the array of selected photos.
                        flipPhoto(clickedPhoto);
                        SMAISSP.selectedPhotos.push(clickedPhoto);
                    }
                }

                // Stop event propagation
                evt.cancelBubble = true;
                if (evt.stopPropagation) {
                    evt.stopPropagation();
                }
            });
        });
    }

    function importSelectedPhotos() {
        // First post the selectedPhotos to backend, then wait
        function jsonForPhoto(photo) {
            return {
                "thumbnail" : photo.getAttribute("src"),
                "name" : photo.getAttribute("smaiss-name"),
                "highQuality" : photo.getAttribute("smaiss-high-quality")
            };
        }

        var jsonPhotos = [];
        for (var i = 0; i < SMAISSP.selectedPhotos.length; i++) {
            var selectedPhoto = SMAISSP.selectedPhotos[i];
            var jsonPhoto = jsonForPhoto(selectedPhoto);
            jsonPhotos.push(jsonPhoto);
        }

        SMAISSP.uploadPhotos(jsonPhotos);
    }

    /* Public */

    return {
        init: function() {
            if (window.fbAsyncInit) {
                // do nothing
                console.log('FB init has already been called');
                return;
            } else {
                window.fbAsyncInit = function() {
                FB.init({
                    appId: '____', // APP ID
                    channelUrl: '//smaiss.com:8080/channel.html', // Channel File
                    status: true, // check login status
                    cookie: true, // enable cookies to allow the server to access the session
                    xfbml: true  // parse XFBML
                }, function (response) {
                    console.log("Facebook API initialized.");
                });

                FB.getLoginStatus(function(response) {
                  if (response.status === 'connected') {
                    console.log("Connected and authenticated.");
                    // The user is logged in and has authenticated the app.
                    var uid = response.authResponse.userID;

                    console.log("Connected, getting albums...");
                    SMAISS_FB.fetchAlbums(uid, "{{ selection_mode }}");

                  } else if (response.status === 'not_authorized') {
                    // The user is logged in to Facebook but has not authenticated the app yet.
                    console.log("Logged in but not authenticated...");
                    FB.login(function(response){
                      if (response.authResponse) {
                            console.log("Authorized, getting albums...");
                            var uid = response.authResponse.userID;
                            SMAISS_FB.fetchAlbums(uid, "{{ selection_mode }}");

                        } else {
                            console.log("Authorization cancelled");
                        }
                    }, {scope: 'user_photos'});
                  } else {
                    // the user isn't logged in to Facebook.
                    console.log("Not logged in ");

                    // TODO this will be blocked by popup blocker...
                    // Create a facebook button and position it in the center of the page
                    // When the user log-in, hide it and show the content.
                    FB.login();
                  }
                });

                // Here we subscribe to the auth.authResponseChange JavaScript event. This event is fired
                // for any authentication related change, such as login, logout or session refresh. This means that
                // whenever someone who was previously logged out tries to log in again, the correct case below
                // will be handled.
                FB.Event.subscribe('auth.authResponseChange', function(response) {
                  // Here we specify what we do with the response anytime this event occurs.
                  if (response.status === 'connected') {
                    // The response object is returned with a status field that lets the app know the current
                    // login status of the person. In this case, we're handling the situation where they
                    // have logged in to the app.
                    console.log("Connected to facebook");
                  } else if (response.status === 'not_authorized') {
                    // In this case, the person is logged into Facebook, but not into the app, so we call
                    // FB.login() to prompt them to do so.
                    // In real-life usage, you wouldn't want to immediately prompt someone to login
                    // like this, for two reasons:
                    // (1) JavaScript created popup windows are blocked by most browsers unless they
                    // result from direct interaction from people using the app (such as a mouse click)
                    // (2) it is a bad experience to be continually prompted to login upon page load.
                    console.log('User logged into facebook but app not authorized.');
                    FB.login();
                  } else {
                    // In this case, the person is not logged into Facebook, so we call the login()
                    // function to prompt them to do so. Note that at this stage there is no indication
                    // of whether they are logged into the app. If they aren't then they'll see the Login
                    // dialog right after they log in to Facebook.
                    // The same caveats as above apply to the FB.login() call here.
                    console.log('User NOT logged into facebook and app not authorized.');
                    FB.login();
                  }
                });
              };

              // Load the SDK asynchronously
              (function(d){
                var js, id = 'facebook-jssdk', ref = d.getElementsByTagName('script')[0];
                if (d.getElementById(id)) {return;}
                js = d.createElement('script'); js.id = id; js.async = true;
                js.src = "//connect.facebook.net/en_US/all.js";
                ref.parentNode.insertBefore(js, ref);
                }(document));
            }
        },

        fetchAlbums: function(uid, selectionMode) {
            FB.api({
             method: 'fql.multiquery',
             queries: {
                /* Select album info */
                query1: 'SELECT object_id,name,photo_count,cover_object_id FROM album WHERE owner = ' + uid,
                /* Select album cover and its id */
                query2: 'SELECT pid,src,src_height FROM photo WHERE object_id IN (SELECT cover_object_id FROM #query1)'
             }
            },
            function(response) {
                var albumsInfo = [];
                var albumsData = response[0];
                var coversData = response[1];
                for (var i = 0; i < albumsData.fql_result_set.length; i++) {
                    var albumData = albumsData.fql_result_set[i];
                    var coverData = coversData.fql_result_set[i];
                    var albumInfo = {
                        albumID : albumData.object_id,
                        title : albumData.name,
                        cover : coverData.src,
                        height : coverData.src_height
                    };
                    albumsInfo.push(albumInfo);
                }

                // Render the albums and register for click events in order to
                // start fetching the album's photos.
                renderAlbumsCover({"albums":albumsInfo});

                // Save the current content in cache.
                cache.facebook = $('#service-content').html();

                SMAISSP.registerElementsForClick(".album-link", function(evt) {
                    if (!evt) {
                        evt = window.event;
                    }

                    // Fetch the photos in the clicked album
                    var albumID = evt.toElement.getAttribute('albumID');
                    fetchAlbum(albumID, selectionMode);

                    // Stop event propagation
                    evt.cancelBubble = true;
                    if (evt.stopPropagation) {
                        evt.stopPropagation();
                    }
                });
            });
        }
    };
})();


var SMAISS_FLICKR = (function() {
    "use strict";

    var _secret;

    function importSelectedPhotos() {
        function jsonForPhoto(photo) {
            return {
                "thumbnail" : photo.getAttribute("src"),
                "name" : photo.getAttribute("smaiss-name"),
                "highQuality" : photo.getAttribute("smaiss-high-quality")
            };
        }

        var jsonPhotos = [];
        for (var i = 0; i < SMAISSP.selectedPhotos.length; i++) {
            var selectedPhoto = SMAISSP.selectedPhotos[i];
            var jsonPhoto = jsonForPhoto(selectedPhoto);// This should be in each separate module, while importSelectedPhotos should be in SMAISS
            jsonPhotos.push(jsonPhoto);
        }

        SMAISSP.uploadPhotos(jsonPhotos);
    }

    return {
        init: function() {
            SMAISSP.registerElementsForClick('#import-button', importSelectedPhotos);
            SMAISSP.registerElementsForClick("#connect-button", function() {
                window.open('http://api.smaiss.com:8080/v0/services/flickr/login','_blank');
            });
            $("a.link").on("click",function(){
                window.open('http://api.smaiss.com:8080/v0/services/flickr/login','_blank');
            });
        },

        isAuthenticated: function() {
            var fov = $.cookie('fov');
            return fov && fov.length > 0;
        },

        authenticate: function(callback) {
            // First get the login URL
            console.log('Authenticating on the backend');
            $.ajax({
                url: 'http://api.smaiss.com:8080/v0/services/flickr/auth'
            }).done(function(response) {
                callback(response.text);
            }).fail(function() {
               // TODO
            });
        },

        fetchPhotosets: function() {
            $.ajax({
                url: 'http://api.smaiss.com:8080/v0/services/flickr/photosets'
            }).done(function(response) {
               // TODO populate mustache templates, see facebook.js
            });
        }

    };

})();

/* global console:false */
/* global Mustache:false */
/* global SMAISSP:false */

var SMAISS_LOCAL = (function() {
    "use strict";

    function importSelectedPhotos() {
        function jsonForPhoto(photo) {
            return {
                "thumbnail" : photo.getAttribute("src"),
                "name" : photo.getAttribute("smaiss-name"),
                "highQuality" : photo.getAttribute("smaiss-high-quality")
            };
        }

        var jsonPhotos = [];
        for (var i = 0; i < SMAISSP.selectedPhotos.length; i++) {
            var selectedPhoto = SMAISSP.selectedPhotos[i];
            var jsonPhoto = jsonForPhoto(selectedPhoto);// This should be in each separate module, while importSelectedPhotos should be in SMAISS
            jsonPhotos.push(jsonPhoto);
        }

        SMAISSP.uploadPhotos(jsonPhotos);
    }

    function initUploader() {
        /*jslint nomen: true, regexp: true */
        /*global $, window, blueimp */

        // Disable drag and drop outside the drop zone
        $(document).bind('drop dragover', function (e) {
            e.preventDefault();
        });

        // Initialize the jQuery File Upload widget:
        $('#fileuload').fileupload({
            // Uncomment the following to send cross-domain cookies:
            //xhrFields: {withCredentials: true},
            url: '//api.smaiss.com:8080/v0/services/local/upload',
            dropZone: $('#drop-zone')
        });

        // Enable iframe cross-domain access via redirect option:
        $('#fileupload').fileupload(
            'option',
            'redirect',
            window.location.href.replace(
                /\/[^\/]*$/,
                '/cors/result.html?%s'
            )
        );

        $('#fileupload').fileupload('option', {
            // Enable image resizing, except for Android and Opera,
            // which actually support image resizing, but fail to
            // send Blob objects via XHR requests:
            disableImageResize: /Android(?!.*Chrome)|Opera/
                .test(window.navigator.userAgent),
            maxFileSize: 5000000,
            acceptFileTypes: /(\.|\/)(gif|jpe?g|png)$/i
        });

        $('#fileupload').fileupload({
            // Immediately submit the image when it's added.
            add: function (e, data) {
                data.submit();
            }
        });

        // Upload server status check for browsers with CORS support:
        if ($.support.cors) {
            $.ajax({
                url: '//api.smaiss.com:8080/v0/services/local/upload/status',
                type: 'HEAD'
            }).fail(function () {
                $('<div class="alert alert-danger"/>')
                    .text('Upload server currently unavailable - ' +
                            new Date())
                    .appendTo('#fileupload');
            });
        }

    }

    /* Public */

    return {
        init: function() {
            SMAISSP.registerElementsForClick('#import-button', importSelectedPhotos);
            initUploader();
        }
    };
})();
