This is part of a side-project I'm developing that include replicating the 
functionality of [filepicker.io](http://www.filepicker.io).

The idea is to show that I can write modern Javascript (although "modern"
become "obsolete" in Javascript after about two weeks...)
