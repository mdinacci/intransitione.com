//
// ViewController.h
// MDRadialProgress
//
//
// Copyright (c) 2013 Marco Dinacci. All rights reserved.

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
