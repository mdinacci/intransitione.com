This is my most recent Objective-C code. It's a reasonably popular (~400 stars
on Github) UIView to draw progress in discrete steps.

Open MDRadialProgress.xcodeproj to see the code and launch the demo app.
See also the README.md file in the project directory.

