A script that reads the Apache logs and produce in output:

* The percentage of off-site requests
* The top 10 URLs
* The customer usage summary 

Usage:

$ python apache_log_parser.py dir_name
