import requests
import json
import sys
import argparse
from lxml import html
from queue import Queue
from threading import Thread
from datetime import datetime

FEATURES = {
    "RealAle": "has_real_ale",
    "Cider": "has_real_cider",
    "MemberDiscountScheme": "has_member_discount_scheme",
    "LocAle": "is_locale_accredited",
    "CaskMarque": "is_cask_marque_accredited",
    "RealHeritagePub": "is_real_heritage",
    "Quiet": "is_quiet",  # facilities
    "Accommodation": "has_accommodation",
    "Bus": "is_close_to_bus_stop",
    "Camping": "has_camping_nearby",
    "DisabledAccess": "has_disabled_access",
    "DogFriendly": "is_dog_friendly",
    "EveningMeals": "has_evening_meals",
    "FamilyFriendly": "is_family_friendly",
    "FunctionRoom": "has_function_room",
    "LinedGlasses": "has_lined_glasses",
    "LiveMusic": "has_live_music",
    "LunchtimeMeals": "has_lunchtime_meals",
    "Newspapers": "has_newspapers",
    "Parking": "has_parking",
    "Garden": "has_garden",
    "RealFire": "has_real_fireplace",
    "Restaurant": "has_restaurant",
    "Smoking": "has_smoking_area",
    "SportsTV": "has_sports_tv",
    "Games": "has_games",
    "WiFi": "has_wifi",
    "Station": "is_close_to_train_station",
    "Metro": "is_close_to_metro",
    "BitCoin": "has_bitcoins"
}


error_file = open("error.log", "w")
has_found_errors = False
pubs = []


class Pub(object):
    """ Helper class to set attributes on a Pub """
    def __init__(self):
        self.features = []
        self.name = ""
        self.description = None
        self.location = None
        self.postcode = None
        self.www_url = None
        self.facebook_url = None
        self.twitter_handle = None
        self.phone_number = None
        self.events_url = None

    def add_feature(self, feature):
        if isinstance(feature, list):
            if len(feature) == 1:
                self.features.append(feature[0])
        else:
            self.features.append(feature)

    def __setattr__(self, key, value):
        if key is "features":
            # Features are added using add_feature, however, the first
            # time the features attribute is assigned, we can't skip it because it needs
            # to be initialized
            if not hasattr(self, "features"):
                super().__setattr__("features", value)
            return

        if isinstance(value, list):
            if len(value) == 1:
                super().__setattr__(key, value[0])
            elif len(value) > 1:
                super().__setattr__(key, value)
        else:
            super().__setattr__(key, value)


def log_error(msg):
    """ Log errors to a file """
    global has_found_errors
    has_found_errors = True
    error_file.write(msg + "\n")


def extract_pub_urls(tree):
    """ Extracts all links to each pub in the given tree and return them """

    pub_hrefs = tree.xpath('//section[@class="pub"]/a/@href')
    urls = ["http://whatpub.com" + pub_url for pub_url in pub_hrefs]
    return urls


def fetch_page(url):
    """ Fetch a page, raise response.HTTPError if an error is found. """

    response = requests.get(url)
    if response.status_code == 200:
        tree = html.fromstring(response.text)
        return tree
    else:
        response.raise_for_status()


def fetch_pub(url):
    """ Fetch a pub from the given url. """

    try:
        response = requests.get(url)
    except requests.exceptions.RequestException:
        return None
    tree = html.fromstring(response.text)

    pub = Pub()

    pub.name = tree.xpath("//article[@id='pub']/div/section[1]/h1/text()")[0]
    pub.description = pub.name
    address = tree.xpath("//article[@id='pub']/div/section[1]/p/text()")
    pub.postcode = address[-1]
    pub.address = " ".join(address)
    pub.www_url = tree.xpath(
        "//article[@id='pub']/div/section/ul/li/img[@alt='Website']/following-sibling::span/a/text()")
    pub.phone_number = tree.xpath("//img[@alt='Telephone']/following-sibling::span/text()")
    pub.location = tree.xpath("//section/p/a[@title='View in Google Maps']/text()")

    # Social links
    pub.facebook_url = tree.xpath(
        "//article[@id='pub']/div/section/ul/li/img[@src='/img/symbols/Facebook.png']/following-sibling::span/a/@href")

    # Extract the features by looking at the alt tag of the images in the list of features.
    features = tree.xpath("//section/ul[@class='pub_features']/li/img/@alt")
    try:
        for feature in features:
            pub.add_feature(FEATURES[feature])
    except KeyError as err:
        if feature.startswith("Visit"):
            # False negative, link to Facebook text
            pass
        else:
            log_error("Missing {0} in {1}".format(err, url))

    pub.last_update = str(datetime.now())
    return pub


def scrape_pub():
    global quiet
    global pubs

    while True:
        pub_url = q.get()
        if quiet is False:
            print("Fetching %s" % pub_url)
        pub = fetch_pub(pub_url)
        pubs.append(pub)
        q.task_done()


def save_to_json(pubs):
    """ Dump the results in a JSON file """
    json.dump([pub.__dict__ for pub in pubs], open("pubs.json", 'w'))


def save_to_sql(pubs):
    """ Save to SQL  """
    statements = []

    # Create an INSERT query for each statement
    for pub in pubs:
        pub_dict = pub.__dict__.items()
        # Extract only the columns where the value is not None and exclude features
        columns = ", ".join([key for key, val in pub_dict if key is not 'features' and val is not None])
        # Extract only the values not None and not in the features dictionary
        values = []
        for key, val in pub_dict:
            if key is not 'features' and val is not None:
                if key is 'location':
                    values.append("St_MakePoint({0})".format(val))
                else:
                    values.append("{0}".format(repr(val)))
        values = ", ".join(values)
        statement = "INSERT INTO PUBS ({0}) VALUES ({1});\n".format(columns, values)
        statements.append(statement)
        if len(pub.features) > 0:
            query = "INSERT INTO pub_features({0}) VALUES ({1});\n".format(", ".join(pub.features),
                                                                          ", ".join(["true" for f in pub.features]))
            statements.append(query)

    with open("pubs.sql", "w") as sql_file:
        sql_file.write("".join(statements))


def show_help():
    print("scrape_whatpub --help for help.")


if __name__ == "__main__":
    quiet = False

    # Quit immediately if there's less than one parameter
    if len(sys.argv) == 1:
        show_help()
        sys.exit(1)

    parser = argparse.ArgumentParser()
    parser.add_argument("-j", "--json", action="store", help="dump results to a JSON file.")
    parser.add_argument("-s", "--sql", action="store", help="dump results to a SQL file in PostgreSQL format.")
    parser.add_argument("-q", "--quiet", action="store", help="don't print progress to stdout.")
    parser.add_argument("location")
    namespace = parser.parse_args()

    quiet = namespace.quiet is not None

    # Build
    # the search url from the parameter given at command line
    location = sys.argv[-1]
    search_url = "http://whatpub.com/search?q={0}&t=ft&p=1&features=Pub%2CRealAle%2COpen".format(location)

    if not quiet:
        print("Starting up...\n")

    try:
        # Fetch results page and get all the pub urls
        first_page_tree = fetch_page(search_url)
        pub_urls = extract_pub_urls(first_page_tree)
    except requests.HTTPError:
        print("Can't parse results page, bailing out...")
        sys.exit(1)

    # Extract pub urls from all pages in the results
    pages_href = first_page_tree.xpath('//div[@class="pager"]/p/a/@href')
    if len(pages_href) > 0:
        pages_url = ["http://whatpub.com" + page_url for page_url in pages_href]
        for page_url in pages_url:
            first_page_tree = fetch_page(page_url)
            pub_urls += extract_pub_urls(first_page_tree)

    q = Queue()
    [q.put(pub_url) for pub_url in pub_urls]

    # Use a few threads to download the results.
    for i in range(4):
        t = Thread(target=scrape_pub)
        t.daemon = True
        t.start()

    # Collect the results
    q.join()

    if namespace.json is not None:
        save_to_json(pubs)

    if namespace.sql is not None:
        save_to_sql(pubs)

    # If no export option is provided, just dump to stdout
    if namespace.json is None and namespace.sql is None:
        # Dump to stdout
        import pprint
        pp = pprint.PrettyPrinter(indent=4)
        pp.pprint([pub.__dict__ for pub in pubs])

    if has_found_errors:
        # Remind us that there are errors in errors.log
        print("*" * 72)
        print("ERRORS FOUND, check errors.log")
        print("*" * 72)
