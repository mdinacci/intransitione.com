There are two projects here. _apache_log_parser_ is a Python2 project that parses Apache log files and print 
some useful statistics.

You can test it by running: 

`
python apache_log_parser.py samples
`

The second project is more recent Python3 and it's a simple scraper used
to extract some information about pubs on the __whatpub.com__ website. I'm using it
as part of a side project and it's still a bit work in progress. 
It requires requests, lxml and cssselect. 

You can test it by running:

`
$ python3 scrape_whatpub.py -j pubs.json dorking (or any other location in UK)
`

I have a much bigger Python project [on Github](https://github.com/mdinacci/rtw) that I preferred not to include in this archive.
